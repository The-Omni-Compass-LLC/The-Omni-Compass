# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
10 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 43.52 | 43.61 | 43.88 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.573e+05 | 1.57e+05 | 1.56e+05 |
| energy per served request (J) | 22.99 | 22.94 | 22.79 |
| power, GPU mean (W) | 248.8 | 248.2 | 246.7 |
| requests served | 6843 | 6843 | 6843 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 88.53 | 88.39 | 88.75 |
| response time, 95th percentile (ms) | 264.8 | 264.1 | 264.9 |
| response time, 99th percentile (ms) | 459.6 | 458.4 | 459.9 |
| temperature, peak (C) | 76.3 | 76 | 76.9 |
| temperature, mean (C) | 62.51 | 62.29 | 63 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.572e+05 | 1.571e+05 | 1.567e+05 |
| power-capped share of samples | 0.7204 | 0.7172 | 0.67 |

## Total: Omni governs against native, 10 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.52 | 43.88 | +0.8% | -0.3869 to +1.114 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.573e+05 | 1.56e+05 | -0.9% | -4021 to +1336 | GAIN, not beyond the noise |
| energy per served request (J) | 22.99 | 22.79 | -0.9% | -0.5876 to +0.1953 | GAIN, not beyond the noise |
| power, GPU mean (W) | 248.8 | 246.7 | -0.9% | -6.363 to +2.108 | GAIN, not beyond the noise |
| requests served | 6843 | 6843 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 88.53 | 88.75 | +0.2% | -1.09 to +1.529 | EVEN, under the floor |
| response time, 95th percentile (ms) | 264.8 | 264.9 | +0.0% | -4.967 to +5.116 | EVEN, under the floor |
| response time, 99th percentile (ms) | 459.6 | 459.9 | +0.1% | -8.317 to +8.913 | EVEN, under the floor |
| temperature, peak (C) | 76.3 | 76.9 | +0.8% | -2.457 to +3.657 | power given, not beyond the noise |
| temperature, mean (C) | 62.51 | 63 | +0.8% | -3.271 to +4.239 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.572e+05 | 1.567e+05 | -0.3% | -2962 to +1936 | EVEN, under the floor |
| power-capped share of samples | 0.7204 | 0.67 | -7.0% | -0.08459 to -0.01623 | LOSS, clear of the noise |

## Observation: omni watching (writes nothing) against native, 10 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.52 | 43.61 | +0.2% | -0.6052 to +0.801 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.573e+05 | 1.57e+05 | -0.2% | -2891 to +2171 | EVEN, under the floor |
| energy per served request (J) | 22.99 | 22.94 | -0.2% | -0.4225 to +0.3172 | EVEN, under the floor |
| power, GPU mean (W) | 248.8 | 248.2 | -0.2% | -4.575 to +3.432 | EVEN, under the floor |
| requests served | 6843 | 6843 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 88.53 | 88.39 | -0.2% | -1.243 to +0.9576 | EVEN, under the floor |
| response time, 95th percentile (ms) | 264.8 | 264.1 | -0.3% | -4.885 to +3.498 | EVEN, under the floor |
| response time, 99th percentile (ms) | 459.6 | 458.4 | -0.3% | -8.117 to +5.753 | EVEN, under the floor |
| temperature, peak (C) | 76.3 | 76 | -0.4% | -3.202 to +2.602 | EVEN, under the floor |
| temperature, mean (C) | 62.51 | 62.29 | -0.4% | -3.378 to +2.933 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.572e+05 | 1.571e+05 | -0.1% | -2432 to +2073 | EVEN, under the floor |
| power-capped share of samples | 0.7204 | 0.7172 | -0.4% | -0.009277 to +0.002943 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 10 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.61 | 43.88 | +0.6% | -0.2012 to +0.7331 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.57e+05 | 1.56e+05 | -0.6% | -2634 to +669.4 | GAIN, not beyond the noise |
| energy per served request (J) | 22.94 | 22.79 | -0.6% | -0.3849 to +0.09782 | GAIN, not beyond the noise |
| power, GPU mean (W) | 248.2 | 246.7 | -0.6% | -4.164 to +1.051 | GAIN, not beyond the noise |
| requests served | 6843 | 6843 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 88.39 | 88.75 | +0.4% | -0.4097 to +1.135 | EVEN, under the floor |
| response time, 95th percentile (ms) | 264.1 | 264.9 | +0.3% | -1.86 to +3.396 | EVEN, under the floor |
| response time, 99th percentile (ms) | 458.4 | 459.9 | +0.3% | -3.781 to +6.741 | EVEN, under the floor |
| temperature, peak (C) | 76 | 76.9 | +1.2% | -0.9607 to +2.761 | power given, not beyond the noise |
| temperature, mean (C) | 62.29 | 63 | +1.1% | -1.333 to +2.747 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.571e+05 | 1.567e+05 | -0.2% | -1528 to +860.6 | EVEN, under the floor |
| power-capped share of samples | 0.7172 | 0.67 | -6.6% | -0.07979 to -0.0147 | LOSS, clear of the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 43.52 -> 43.88 served requests per kJ, difference +0.3638 (95% interval -0.3869 to +1.114).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 2 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| omni | 3 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| omni | 4 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| omni | 5 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| omni | 6 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| omni | 7 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| omni | 8 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| omni | 9 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| omni | 10 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| watch | 1 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 2 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 3 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| watch | 4 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 5 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 6 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 7 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 8 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| watch | 9 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 10 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 312.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*