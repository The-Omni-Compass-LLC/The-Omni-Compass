# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 44.52 | 43.31 | 43.79 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 4.557e+04 | 4.686e+04 | 4.634e+04 |
| energy per served request (J) | 22.46 | 23.1 | 22.84 |
| power, GPU mean (W) | 214.6 | 220.7 | 218.2 |
| requests served | 2029 | 2029 | 2029 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 89.92 | 89.88 | 90.03 |
| response time, 95th percentile (ms) | 283.9 | 284.3 | 285.2 |
| response time, 99th percentile (ms) | 478.9 | 478.6 | 479 |
| temperature, peak (C) | 69 | 69 | 69 |
| temperature, mean (C) | 53.2 | 53.1 | 53.17 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 4.656e+04 | 4.654e+04 | 4.654e+04 |
| power-capped share of samples | 0.626 | 0.6322 | 0.6201 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.52 | 43.79 | -1.6% | -1.451 to -0.01807 | power given, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.557e+04 | 4.634e+04 | +1.7% | -22.5 to +1560 | power given, not beyond the noise |
| energy per served request (J) | 22.46 | 22.84 | +1.7% | -0.01109 to +0.7689 | power given, not beyond the noise |
| power, GPU mean (W) | 214.6 | 218.2 | +1.7% | -0.1444 to +7.314 | power given, not beyond the noise |
| requests served | 2029 | 2029 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 89.92 | 90.03 | +0.1% | -0.4412 to +0.6492 | EVEN, under the floor |
| response time, 95th percentile (ms) | 283.9 | 285.2 | +0.5% | -1.905 to +4.562 | EVEN, under the floor |
| response time, 99th percentile (ms) | 478.9 | 479 | +0.0% | -0.1149 to +0.3765 | EVEN, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 53.2 | 53.17 | -0.0% | -0.3813 to +0.3339 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.656e+04 | 4.654e+04 | -0.0% | -168 to +135.2 | EVEN, under the floor |
| power-capped share of samples | 0.626 | 0.6201 | -0.9% | -0.03353 to +0.02174 | LOSS, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.52 | 43.31 | -2.7% | -2.956 to +0.5276 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.557e+04 | 4.686e+04 | +2.8% | -595.4 to +3170 | power given, not beyond the noise |
| energy per served request (J) | 22.46 | 23.1 | +2.8% | -0.2935 to +1.562 | power given, not beyond the noise |
| power, GPU mean (W) | 214.6 | 220.7 | +2.8% | -2.805 to +14.94 | power given, not beyond the noise |
| requests served | 2029 | 2029 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 89.92 | 89.88 | -0.0% | -0.867 to +0.7786 | EVEN, under the floor |
| response time, 95th percentile (ms) | 283.9 | 284.3 | +0.1% | -5.949 to +6.79 | EVEN, under the floor |
| response time, 99th percentile (ms) | 478.9 | 478.6 | -0.1% | -5.6 to +5.068 | EVEN, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 53.2 | 53.1 | -0.2% | -0.8671 to +0.6648 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.656e+04 | 4.654e+04 | -0.0% | -364.5 to +340 | EVEN, under the floor |
| power-capped share of samples | 0.626 | 0.6322 | +1.0% | +0.001193 to +0.01125 | GAIN, clear of the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.31 | 43.79 | +1.1% | -1.144 to +2.103 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.686e+04 | 4.634e+04 | -1.1% | -2242 to +1205 | GAIN, not beyond the noise |
| energy per served request (J) | 23.1 | 22.84 | -1.1% | -1.105 to +0.594 | GAIN, not beyond the noise |
| power, GPU mean (W) | 220.7 | 218.2 | -1.1% | -10.61 to +5.653 | GAIN, not beyond the noise |
| requests served | 2029 | 2029 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 89.88 | 90.03 | +0.2% | -0.2366 to +0.533 | EVEN, under the floor |
| response time, 95th percentile (ms) | 284.3 | 285.2 | +0.3% | -2.642 to +4.458 | EVEN, under the floor |
| response time, 99th percentile (ms) | 478.6 | 479 | +0.1% | -4.916 to +5.709 | EVEN, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 53.1 | 53.17 | +0.1% | -0.3425 to +0.4974 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.654e+04 | 4.654e+04 | -0.0% | -208.1 to +199.8 | EVEN, under the floor |
| power-capped share of samples | 0.6322 | 0.6201 | -1.9% | -0.03583 to +0.0116 | LOSS, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 44.52 -> 43.79 served requests per kJ, difference -0.7345 (95% interval -1.451 to -0.01807).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: LOSS.**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 2 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 2 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 16.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*