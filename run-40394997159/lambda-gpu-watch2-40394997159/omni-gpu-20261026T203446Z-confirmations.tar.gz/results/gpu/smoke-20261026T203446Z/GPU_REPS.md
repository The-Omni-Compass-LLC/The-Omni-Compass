# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 8e62252e1f28; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 57.76 | 57.85 | 58.27 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.178e+04 | 2.175e+04 | 2.159e+04 |
| energy per served request (J) | 17.32 | 17.29 | 17.16 |
| power, GPU mean (W) | 102.9 | 102.7 | 102 |
| requests served | 1258 | 1258 | 1258 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 148.8 | 148.8 | 147.8 |
| response time, 95th percentile (ms) | 497.1 | 509 | 508.8 |
| response time, 99th percentile (ms) | 745 | 751.8 | 749 |
| temperature, peak (C) | 65.33 | 65.33 | 66 |
| temperature, mean (C) | 57.74 | 58.64 | 58.72 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.178e+04 | 2.183e+04 | 2.182e+04 |
| power-capped share of samples | 0.8021 | 0.804 | 0.8027 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.76 | 58.27 | +0.9% | -1.58 to +2.595 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.178e+04 | 2.159e+04 | -0.9% | -974.7 to +589.2 | GAIN, not beyond the noise |
| energy per served request (J) | 17.32 | 17.16 | -0.9% | -0.7748 to +0.4683 | GAIN, not beyond the noise |
| power, GPU mean (W) | 102.9 | 102 | -0.9% | -4.591 to +2.77 | GAIN, not beyond the noise |
| requests served | 1258 | 1258 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 148.8 | 147.8 | -0.6% | -8.577 to +6.725 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 497.1 | 508.8 | +2.3% | -57.97 to +81.31 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 745 | 749 | +0.5% | -34.51 to +42.43 | LOSS, not beyond the noise |
| temperature, peak (C) | 65.33 | 66 | +1.0% | -2.202 to +3.535 | power given, not beyond the noise |
| temperature, mean (C) | 57.74 | 58.72 | +1.7% | -3.332 to +5.289 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.178e+04 | 2.182e+04 | +0.2% | -289.3 to +377.5 | EVEN, under the floor |
| power-capped share of samples | 0.8021 | 0.8027 | +0.1% | -0.008275 to +0.009538 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.76 | 57.85 | +0.2% | -1.654 to +1.844 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.178e+04 | 2.175e+04 | -0.2% | -689.3 to +615.2 | EVEN, under the floor |
| energy per served request (J) | 17.32 | 17.29 | -0.2% | -0.548 to +0.4891 | EVEN, under the floor |
| power, GPU mean (W) | 102.9 | 102.7 | -0.2% | -3.257 to +2.897 | EVEN, under the floor |
| requests served | 1258 | 1258 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 148.8 | 148.8 | +0.0% | -9.977 to +10.07 | EVEN, under the floor |
| response time, 95th percentile (ms) | 497.1 | 509 | +2.4% | -53.93 to +77.64 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 745 | 751.8 | +0.9% | -26.42 to +39.9 | LOSS, not beyond the noise |
| temperature, peak (C) | 65.33 | 65.33 | +0.0% | -2.484 to +2.484 | EVEN, under the floor |
| temperature, mean (C) | 57.74 | 58.64 | +1.5% | -3.156 to +4.943 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.178e+04 | 2.183e+04 | +0.2% | -239.4 to +343.5 | EVEN, under the floor |
| power-capped share of samples | 0.8021 | 0.804 | +0.2% | -0.002181 to +0.005969 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.85 | 58.27 | +0.7% | -1.141 to +1.966 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.175e+04 | 2.159e+04 | -0.7% | -743.4 to +432 | GAIN, not beyond the noise |
| energy per served request (J) | 17.29 | 17.16 | -0.7% | -0.591 to +0.3434 | GAIN, not beyond the noise |
| power, GPU mean (W) | 102.7 | 102 | -0.7% | -3.491 to +2.03 | GAIN, not beyond the noise |
| requests served | 1258 | 1258 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 148.8 | 147.8 | -0.7% | -3.412 to +1.468 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 509 | 508.8 | -0.0% | -4.107 to +3.733 | EVEN, under the floor |
| response time, 99th percentile (ms) | 751.8 | 749 | -0.4% | -9.513 to +3.952 | EVEN, under the floor |
| temperature, peak (C) | 65.33 | 66 | +1.0% | -0.7677 to +2.101 | power given, not beyond the noise |
| temperature, mean (C) | 58.64 | 58.72 | +0.1% | -0.2099 to +0.379 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.183e+04 | 2.182e+04 | -0.0% | -60.85 to +45 | EVEN, under the floor |
| power-capped share of samples | 0.804 | 0.8027 | -0.2% | -0.00616 to +0.003635 | EVEN, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 57.76 -> 58.27 served requests per kJ, difference +0.5078 (95% interval -1.58 to +2.595).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: EVEN (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*