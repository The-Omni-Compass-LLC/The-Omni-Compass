# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 40.81 | 40.52 | 40.84 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 4.751e+04 | 4.785e+04 | 4.748e+04 |
| energy per served request (J) | 24.5 | 24.68 | 24.49 |
| power, GPU mean (W) | 223.8 | 225.4 | 223.6 |
| requests served | 1939 | 1939 | 1939 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 93.18 | 93.31 | 93.37 |
| response time, 95th percentile (ms) | 293.1 | 294.5 | 293.3 |
| response time, 99th percentile (ms) | 495.3 | 496 | 496.6 |
| temperature, peak (C) | 71.67 | 72 | 71.67 |
| temperature, mean (C) | 54.79 | 54.93 | 54.91 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 4.813e+04 | 4.807e+04 | 4.811e+04 |
| power-capped share of samples | 0.6261 | 0.6299 | 0.6212 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.81 | 40.84 | +0.1% | -1.062 to +1.117 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.751e+04 | 4.748e+04 | -0.1% | -1298 to +1237 | EVEN, under the floor |
| energy per served request (J) | 24.5 | 24.49 | -0.1% | -0.6696 to +0.6381 | EVEN, under the floor |
| power, GPU mean (W) | 223.8 | 223.6 | -0.1% | -6.183 to +5.856 | EVEN, under the floor |
| requests served | 1939 | 1939 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 93.18 | 93.37 | +0.2% | -0.2343 to +0.6117 | EVEN, under the floor |
| response time, 95th percentile (ms) | 293.1 | 293.3 | +0.1% | -3.71 to +4.068 | EVEN, under the floor |
| response time, 99th percentile (ms) | 495.3 | 496.6 | +0.3% | -1.917 to +4.401 | EVEN, under the floor |
| temperature, peak (C) | 71.67 | 71.67 | +0.0% | -2.484 to +2.484 | EVEN, under the floor |
| temperature, mean (C) | 54.79 | 54.91 | +0.2% | -0.392 to +0.6414 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.813e+04 | 4.811e+04 | -0.0% | -236.7 to +196.9 | EVEN, under the floor |
| power-capped share of samples | 0.6261 | 0.6212 | -0.8% | -0.05328 to +0.04361 | LOSS, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.81 | 40.52 | -0.7% | -2.184 to +1.595 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.751e+04 | 4.785e+04 | +0.7% | -1877 to +2564 | power given, not beyond the noise |
| energy per served request (J) | 24.5 | 24.68 | +0.7% | -0.9682 to +1.322 | power given, not beyond the noise |
| power, GPU mean (W) | 223.8 | 225.4 | +0.7% | -8.845 to +12.08 | power given, not beyond the noise |
| requests served | 1939 | 1939 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 93.18 | 93.31 | +0.1% | -0.217 to +0.4878 | EVEN, under the floor |
| response time, 95th percentile (ms) | 293.1 | 294.5 | +0.5% | -1.777 to +4.622 | EVEN, under the floor |
| response time, 99th percentile (ms) | 495.3 | 496 | +0.1% | -6.322 to +7.627 | EVEN, under the floor |
| temperature, peak (C) | 71.67 | 72 | +0.5% | -1.101 to +1.768 | EVEN, under the floor |
| temperature, mean (C) | 54.79 | 54.93 | +0.3% | -0.2077 to +0.4868 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.813e+04 | 4.807e+04 | -0.1% | -277.1 to +152.3 | EVEN, under the floor |
| power-capped share of samples | 0.6261 | 0.6299 | +0.6% | -0.02524 to +0.03285 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.52 | 40.84 | +0.8% | -1.925 to +2.57 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.785e+04 | 4.748e+04 | -0.8% | -2993 to +2246 | GAIN, not beyond the noise |
| energy per served request (J) | 24.68 | 24.49 | -0.8% | -1.544 to +1.158 | GAIN, not beyond the noise |
| power, GPU mean (W) | 225.4 | 223.6 | -0.8% | -14.19 to +10.63 | GAIN, not beyond the noise |
| requests served | 1939 | 1939 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 93.31 | 93.37 | +0.1% | -0.4983 to +0.6049 | EVEN, under the floor |
| response time, 95th percentile (ms) | 294.5 | 293.3 | -0.4% | -2.415 to -0.07234 | EVEN, under the floor |
| response time, 99th percentile (ms) | 496 | 496.6 | +0.1% | -4.97 to +6.15 | EVEN, under the floor |
| temperature, peak (C) | 72 | 71.67 | -0.5% | -1.768 to +1.101 | EVEN, under the floor |
| temperature, mean (C) | 54.93 | 54.91 | -0.0% | -0.2187 to +0.189 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.807e+04 | 4.811e+04 | +0.1% | -237.2 to +322.1 | EVEN, under the floor |
| power-capped share of samples | 0.6299 | 0.6212 | -1.4% | -0.04059 to +0.02331 | LOSS, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 40.81 -> 40.84 served requests per kJ, difference +0.02781 (95% interval -1.062 to +1.117).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 2 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 16.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*