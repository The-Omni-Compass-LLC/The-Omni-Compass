# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
10 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 41.53 | 41.68 | 41.83 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.555e+05 | 1.55e+05 | 1.544e+05 |
| energy per served request (J) | 24.08 | 23.99 | 23.91 |
| power, GPU mean (W) | 245.9 | 245 | 244.2 |
| requests served | 6458 | 6458 | 6458 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 84.26 | 84.22 | 84.37 |
| response time, 95th percentile (ms) | 241.3 | 240.6 | 241 |
| response time, 99th percentile (ms) | 422.2 | 421.8 | 421.2 |
| temperature, peak (C) | 74.1 | 74.3 | 74.1 |
| temperature, mean (C) | 58.19 | 58.23 | 57.99 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.554e+05 | 1.553e+05 | 1.541e+05 |
| power-capped share of samples | 0.7128 | 0.7118 | 0.5923 |

## Total: Omni governs against native, 10 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.53 | 41.83 | +0.7% | +0.05027 to +0.5368 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.555e+05 | 1.544e+05 | -0.7% | -1994 to -185.3 | GAIN, clear of the noise |
| energy per served request (J) | 24.08 | 23.91 | -0.7% | -0.3088 to -0.02869 | GAIN, clear of the noise |
| power, GPU mean (W) | 245.9 | 244.2 | -0.7% | -3.154 to -0.3005 | GAIN, clear of the noise |
| requests served | 6458 | 6458 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 84.26 | 84.37 | +0.1% | +0.04014 to +0.1741 | EVEN, under the floor |
| response time, 95th percentile (ms) | 241.3 | 241 | -0.1% | -0.9335 to +0.4715 | EVEN, under the floor |
| response time, 99th percentile (ms) | 422.2 | 421.2 | -0.2% | -3.129 to +1.082 | EVEN, under the floor |
| temperature, peak (C) | 74.1 | 74.1 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 58.19 | 57.99 | -0.4% | -0.3625 to -0.05251 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.554e+05 | 1.541e+05 | -0.8% | -1555 to -1041 | GAIN, clear of the noise |
| power-capped share of samples | 0.7128 | 0.5923 | -16.9% | -0.1355 to -0.1055 | LOSS, clear of the noise |

## Observation: omni watching (writes nothing) against native, 10 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.53 | 41.68 | +0.4% | -0.03669 to +0.3313 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.555e+05 | 1.55e+05 | -0.3% | -1229 to +143.4 | EVEN, under the floor |
| energy per served request (J) | 24.08 | 23.99 | -0.3% | -0.1904 to +0.02221 | EVEN, under the floor |
| power, GPU mean (W) | 245.9 | 245 | -0.4% | -1.949 to +0.2225 | EVEN, under the floor |
| requests served | 6458 | 6458 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 84.26 | 84.22 | -0.0% | -0.08388 to +0.004885 | EVEN, under the floor |
| response time, 95th percentile (ms) | 241.3 | 240.6 | -0.3% | -1.064 to -0.1644 | EVEN, under the floor |
| response time, 99th percentile (ms) | 422.2 | 421.8 | -0.1% | -1.798 to +1.044 | EVEN, under the floor |
| temperature, peak (C) | 74.1 | 74.3 | +0.3% | -0.1016 to +0.5016 | EVEN, under the floor |
| temperature, mean (C) | 58.19 | 58.23 | +0.1% | -0.09931 to +0.1703 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.554e+05 | 1.553e+05 | -0.0% | -189.1 to +39.47 | EVEN, under the floor |
| power-capped share of samples | 0.7128 | 0.7118 | -0.1% | -0.005764 to +0.0038 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 10 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.68 | 41.83 | +0.4% | -0.158 to +0.4504 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.55e+05 | 1.544e+05 | -0.4% | -1680 to +586.3 | EVEN, under the floor |
| energy per served request (J) | 23.99 | 23.91 | -0.4% | -0.2602 to +0.09079 | EVEN, under the floor |
| power, GPU mean (W) | 245 | 244.2 | -0.4% | -2.655 to +0.9266 | EVEN, under the floor |
| requests served | 6458 | 6458 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 84.22 | 84.37 | +0.2% | +0.08467 to +0.2086 | EVEN, under the floor |
| response time, 95th percentile (ms) | 240.6 | 241 | +0.2% | -0.3218 to +1.088 | EVEN, under the floor |
| response time, 99th percentile (ms) | 421.8 | 421.2 | -0.2% | -2.994 to +1.701 | EVEN, under the floor |
| temperature, peak (C) | 74.3 | 74.1 | -0.3% | -0.5016 to +0.1016 | EVEN, under the floor |
| temperature, mean (C) | 58.23 | 57.99 | -0.4% | -0.2939 to -0.1922 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.553e+05 | 1.541e+05 | -0.8% | -1431 to -1016 | GAIN, clear of the noise |
| power-capped share of samples | 0.7118 | 0.5923 | -16.8% | -0.1332 to -0.1058 | LOSS, clear of the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 41.53 -> 41.83 served requests per kJ, difference +0.2935 (95% interval +0.05027 to +0.5368).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): EVEN, under the floor.
**Result, by rule: GAIN (within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 2 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 3 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 4 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 5 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 6 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 7 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| omni | 8 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 9 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 10 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| watch | 1 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 2 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 3 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 4 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 5 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 6 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 7 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 8 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 9 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 10 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 540.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*