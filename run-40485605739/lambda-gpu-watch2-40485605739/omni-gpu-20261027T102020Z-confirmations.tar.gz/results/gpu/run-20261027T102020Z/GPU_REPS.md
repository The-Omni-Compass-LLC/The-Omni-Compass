# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
10 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 42.09 | 42.08 | 42.38 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.545e+05 | 1.545e+05 | 1.534e+05 |
| energy per served request (J) | 23.76 | 23.77 | 23.6 |
| power, GPU mean (W) | 244.3 | 244.4 | 242.6 |
| requests served | 6502 | 6502 | 6502 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 85.24 | 85.28 | 85.4 |
| response time, 95th percentile (ms) | 245.7 | 245.6 | 245.6 |
| response time, 99th percentile (ms) | 429.7 | 430.5 | 430.2 |
| temperature, peak (C) | 72.4 | 72.4 | 72.3 |
| temperature, mean (C) | 56.46 | 56.53 | 56.17 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.552e+05 | 1.553e+05 | 1.534e+05 |
| power-capped share of samples | 0.7141 | 0.7127 | 0.5839 |

## Total: Omni governs against native, 10 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.09 | 42.38 | +0.7% | -0.0268 to +0.605 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.545e+05 | 1.534e+05 | -0.7% | -2201 to +96.96 | GAIN, not beyond the noise |
| energy per served request (J) | 23.76 | 23.6 | -0.7% | -0.3385 to +0.01491 | GAIN, not beyond the noise |
| power, GPU mean (W) | 244.3 | 242.6 | -0.7% | -3.488 to +0.1568 | GAIN, not beyond the noise |
| requests served | 6502 | 6502 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 85.24 | 85.4 | +0.2% | +0.03143 to +0.2882 | EVEN, under the floor |
| response time, 95th percentile (ms) | 245.7 | 245.6 | -0.0% | -1.242 to +1.037 | EVEN, under the floor |
| response time, 99th percentile (ms) | 429.7 | 430.2 | +0.1% | -0.7359 to +1.777 | EVEN, under the floor |
| temperature, peak (C) | 72.4 | 72.3 | -0.1% | -0.6278 to +0.4278 | EVEN, under the floor |
| temperature, mean (C) | 56.46 | 56.17 | -0.5% | -0.3981 to -0.1897 | GAIN, clear of the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.552e+05 | 1.534e+05 | -1.1% | -2252 to -1303 | GAIN, clear of the noise |
| power-capped share of samples | 0.7141 | 0.5839 | -18.2% | -0.1427 to -0.1177 | LOSS, clear of the noise |

## Observation: omni watching (writes nothing) against native, 10 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.09 | 42.08 | -0.0% | -0.4229 to +0.391 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.545e+05 | 1.545e+05 | +0.0% | -1431 to +1554 | EVEN, under the floor |
| energy per served request (J) | 23.76 | 23.77 | +0.0% | -0.2201 to +0.239 | EVEN, under the floor |
| power, GPU mean (W) | 244.3 | 244.4 | +0.0% | -2.274 to +2.459 | EVEN, under the floor |
| requests served | 6502 | 6502 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 85.24 | 85.28 | +0.0% | -0.03501 to +0.1144 | EVEN, under the floor |
| response time, 95th percentile (ms) | 245.7 | 245.6 | -0.0% | -0.8852 to +0.6644 | EVEN, under the floor |
| response time, 99th percentile (ms) | 429.7 | 430.5 | +0.2% | +0.101 to +1.688 | EVEN, under the floor |
| temperature, peak (C) | 72.4 | 72.4 | +0.0% | -0.4769 to +0.4769 | EVEN, under the floor |
| temperature, mean (C) | 56.46 | 56.53 | +0.1% | +0.03824 to +0.09894 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.552e+05 | 1.553e+05 | +0.1% | -46.15 to +260.9 | EVEN, under the floor |
| power-capped share of samples | 0.7141 | 0.7127 | -0.2% | -0.00501 to +0.002077 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 10 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.08 | 42.38 | +0.7% | -0.05592 to +0.666 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.545e+05 | 1.534e+05 | -0.7% | -2422 to +194.1 | GAIN, not beyond the noise |
| energy per served request (J) | 23.77 | 23.6 | -0.7% | -0.3725 to +0.02985 | GAIN, not beyond the noise |
| power, GPU mean (W) | 244.4 | 242.6 | -0.7% | -3.829 to +0.313 | GAIN, not beyond the noise |
| requests served | 6502 | 6502 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 85.28 | 85.4 | +0.1% | +0.001051 to +0.2392 | EVEN, under the floor |
| response time, 95th percentile (ms) | 245.6 | 245.6 | +0.0% | -1.277 to +1.292 | EVEN, under the floor |
| response time, 99th percentile (ms) | 430.5 | 430.2 | -0.1% | -1.54 to +0.7921 | EVEN, under the floor |
| temperature, peak (C) | 72.4 | 72.3 | -0.1% | -0.506 to +0.306 | EVEN, under the floor |
| temperature, mean (C) | 56.53 | 56.17 | -0.6% | -0.4626 to -0.2624 | GAIN, clear of the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.553e+05 | 1.534e+05 | -1.2% | -2346 to -1424 | GAIN, clear of the noise |
| power-capped share of samples | 0.7127 | 0.5839 | -18.1% | -0.1408 to -0.1166 | LOSS, clear of the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 42.09 -> 42.38 served requests per kJ, difference +0.2891 (95% interval -0.0268 to +0.605).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| omni | 2 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 3 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 4 | 302 | 0 | n/a | n/a | 0 | 302 | 0 |
| omni | 5 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 6 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 7 | 302 | 0 | n/a | n/a | 0 | 302 | 0 |
| omni | 8 | 303 | 0 | n/a | n/a | 0 | 303 | 0 |
| omni | 9 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| omni | 10 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| watch | 1 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 2 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 3 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 4 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 5 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 6 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 7 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 8 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 9 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 10 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 485.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*