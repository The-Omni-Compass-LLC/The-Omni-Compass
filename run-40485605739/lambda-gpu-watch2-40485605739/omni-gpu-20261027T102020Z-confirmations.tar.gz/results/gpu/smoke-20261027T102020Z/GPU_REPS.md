# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 41.16 | 41.43 | 41.02 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 4.736e+04 | 4.704e+04 | 4.751e+04 |
| energy per served request (J) | 24.3 | 24.13 | 24.38 |
| power, GPU mean (W) | 223 | 221.5 | 223.7 |
| requests served | 1949 | 1949 | 1949 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 93.7 | 93.77 | 93.8 |
| response time, 95th percentile (ms) | 295.5 | 297 | 296.9 |
| response time, 99th percentile (ms) | 498.5 | 498.3 | 498.3 |
| temperature, peak (C) | 68.67 | 69 | 69 |
| temperature, mean (C) | 53.23 | 53.3 | 53.37 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 4.763e+04 | 4.765e+04 | 4.768e+04 |
| power-capped share of samples | 0.6282 | 0.6327 | 0.6366 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.16 | 41.02 | -0.3% | -2.014 to +1.748 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.736e+04 | 4.751e+04 | +0.3% | -2010 to +2320 | EVEN, under the floor |
| energy per served request (J) | 24.3 | 24.38 | +0.3% | -1.031 to +1.191 | EVEN, under the floor |
| power, GPU mean (W) | 223 | 223.7 | +0.3% | -9.531 to +10.92 | EVEN, under the floor |
| requests served | 1949 | 1949 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 93.7 | 93.8 | +0.1% | -0.5922 to +0.7907 | EVEN, under the floor |
| response time, 95th percentile (ms) | 295.5 | 296.9 | +0.5% | -3.329 to +6.197 | EVEN, under the floor |
| response time, 99th percentile (ms) | 498.5 | 498.3 | -0.0% | -2.753 to +2.305 | EVEN, under the floor |
| temperature, peak (C) | 68.67 | 69 | +0.5% | -1.101 to +1.768 | EVEN, under the floor |
| temperature, mean (C) | 53.23 | 53.37 | +0.3% | -0.5972 to +0.8726 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.763e+04 | 4.768e+04 | +0.1% | -220.3 to +316 | EVEN, under the floor |
| power-capped share of samples | 0.6282 | 0.6366 | +1.3% | -0.03696 to +0.05392 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.16 | 41.43 | +0.7% | -1.079 to +1.635 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.736e+04 | 4.704e+04 | -0.7% | -1872 to +1234 | GAIN, not beyond the noise |
| energy per served request (J) | 24.3 | 24.13 | -0.7% | -0.9606 to +0.6334 | GAIN, not beyond the noise |
| power, GPU mean (W) | 223 | 221.5 | -0.7% | -8.826 to +5.834 | GAIN, not beyond the noise |
| requests served | 1949 | 1949 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 93.7 | 93.77 | +0.1% | -0.3764 to +0.5167 | EVEN, under the floor |
| response time, 95th percentile (ms) | 295.5 | 297 | +0.5% | -2.259 to +5.301 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 498.5 | 498.3 | -0.1% | -3.429 to +2.927 | EVEN, under the floor |
| temperature, peak (C) | 68.67 | 69 | +0.5% | -1.101 to +1.768 | EVEN, under the floor |
| temperature, mean (C) | 53.23 | 53.3 | +0.1% | -0.7294 to +0.8579 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.763e+04 | 4.765e+04 | +0.0% | -364.7 to +399.5 | EVEN, under the floor |
| power-capped share of samples | 0.6282 | 0.6327 | +0.7% | -0.04576 to +0.05488 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.43 | 41.02 | -1.0% | -1.219 to +0.3969 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.704e+04 | 4.751e+04 | +1.0% | -458.6 to +1407 | power given, not beyond the noise |
| energy per served request (J) | 24.13 | 24.38 | +1.0% | -0.2353 to +0.7217 | power given, not beyond the noise |
| power, GPU mean (W) | 221.5 | 223.7 | +1.0% | -2.254 to +6.63 | power given, not beyond the noise |
| requests served | 1949 | 1949 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 93.77 | 93.8 | +0.0% | -0.2219 to +0.2801 | EVEN, under the floor |
| response time, 95th percentile (ms) | 297 | 296.9 | -0.0% | -2.645 to +2.47 | EVEN, under the floor |
| response time, 99th percentile (ms) | 498.3 | 498.3 | +0.0% | -2.401 to +2.455 | EVEN, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 53.3 | 53.37 | +0.1% | -0.1344 to +0.2813 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.765e+04 | 4.768e+04 | +0.1% | -168.9 to +229.9 | EVEN, under the floor |
| power-capped share of samples | 0.6327 | 0.6366 | +0.6% | -0.01983 to +0.02766 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 41.16 -> 41.02 served requests per kJ, difference -0.1331 (95% interval -2.014 to +1.748).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 2 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 12.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*