# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 8e62252e1f28; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 57.44 | 56.95 | 57.29 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.195e+04 | 2.215e+04 | 2.201e+04 |
| energy per served request (J) | 17.41 | 17.56 | 17.46 |
| power, GPU mean (W) | 103.7 | 104.6 | 104 |
| requests served | 1261 | 1261 | 1261 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 148.9 | 151.1 | 151.5 |
| response time, 95th percentile (ms) | 486.2 | 500.8 | 507.3 |
| response time, 99th percentile (ms) | 736.7 | 746.9 | 752.7 |
| temperature, peak (C) | 64 | 64 | 64 |
| temperature, mean (C) | 56.76 | 57.44 | 57.43 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.182e+04 | 2.187e+04 | 2.185e+04 |
| power-capped share of samples | 0.8005 | 0.8018 | 0.8018 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.44 | 57.29 | -0.3% | -1.616 to +1.311 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.195e+04 | 2.201e+04 | +0.3% | -502.6 to +616.3 | EVEN, under the floor |
| energy per served request (J) | 17.41 | 17.46 | +0.3% | -0.3986 to +0.4888 | EVEN, under the floor |
| power, GPU mean (W) | 103.7 | 104 | +0.3% | -2.377 to +2.903 | EVEN, under the floor |
| requests served | 1261 | 1261 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 148.9 | 151.5 | +1.7% | -7.376 to +12.54 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 486.2 | 507.3 | +4.3% | -54.22 to +96.5 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 736.7 | 752.7 | +2.2% | -47.48 to +79.62 | LOSS, not beyond the noise |
| temperature, peak (C) | 64 | 64 | +0.0% | -2.484 to +2.484 | EVEN, under the floor |
| temperature, mean (C) | 56.76 | 57.43 | +1.2% | -2.302 to +3.65 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.182e+04 | 2.185e+04 | +0.1% | -147.9 to +212.4 | EVEN, under the floor |
| power-capped share of samples | 0.8005 | 0.8018 | +0.2% | -0.01034 to +0.01287 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.44 | 56.95 | -0.9% | -3.693 to +2.702 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.195e+04 | 2.215e+04 | +0.9% | -1041 to +1423 | power given, not beyond the noise |
| energy per served request (J) | 17.41 | 17.56 | +0.9% | -0.8259 to +1.128 | power given, not beyond the noise |
| power, GPU mean (W) | 103.7 | 104.6 | +0.9% | -4.92 to +6.713 | power given, not beyond the noise |
| requests served | 1261 | 1261 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 148.9 | 151.1 | +1.4% | -7.444 to +11.72 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 486.2 | 500.8 | +3.0% | -64.67 to +93.87 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 736.7 | 746.9 | +1.4% | -52.06 to +72.62 | LOSS, not beyond the noise |
| temperature, peak (C) | 64 | 64 | +0.0% | -2.484 to +2.484 | EVEN, under the floor |
| temperature, mean (C) | 56.76 | 57.44 | +1.2% | -2.044 to +3.4 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.182e+04 | 2.187e+04 | +0.3% | -116.2 to +232.4 | EVEN, under the floor |
| power-capped share of samples | 0.8005 | 0.8018 | +0.2% | -0.02631 to +0.02883 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 56.95 | 57.29 | +0.6% | -1.901 to +2.588 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.215e+04 | 2.201e+04 | -0.6% | -999 to +731.3 | GAIN, not beyond the noise |
| energy per served request (J) | 17.56 | 17.46 | -0.6% | -0.7922 to +0.58 | GAIN, not beyond the noise |
| power, GPU mean (W) | 104.6 | 104 | -0.6% | -4.723 to +3.456 | GAIN, not beyond the noise |
| requests served | 1261 | 1261 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 151.1 | 151.5 | +0.3% | -0.7059 to +1.593 | EVEN, under the floor |
| response time, 95th percentile (ms) | 500.8 | 507.3 | +1.3% | -7.34 to +20.42 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 746.9 | 752.7 | +0.8% | -12.35 to +23.93 | LOSS, not beyond the noise |
| temperature, peak (C) | 64 | 64 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 57.44 | 57.43 | -0.0% | -0.288 to +0.2792 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.187e+04 | 2.185e+04 | -0.1% | -84.52 to +32.78 | EVEN, under the floor |
| power-capped share of samples | 0.8018 | 0.8018 | +0.0% | -0.02713 to +0.02713 | EVEN, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 57.44 -> 57.29 served requests per kJ, difference -0.1523 (95% interval -1.616 to +1.311).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: EVEN (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*