# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
10 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 8e62252e1f28; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 40.2 | 40.09 | 40.25 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.616e+05 | 1.62e+05 | 1.614e+05 |
| energy per served request (J) | 24.88 | 24.94 | 24.85 |
| power, GPU mean (W) | 255.5 | 256.2 | 255.2 |
| requests served | 6494 | 6494 | 6494 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 86.88 | 86.76 | 86.72 |
| response time, 95th percentile (ms) | 253.4 | 253.1 | 253.3 |
| response time, 99th percentile (ms) | 442.7 | 442.8 | 441.6 |
| temperature, peak (C) | 76.3 | 76 | 75.9 |
| temperature, mean (C) | 62.48 | 62.16 | 62.28 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.626e+05 | 1.625e+05 | 1.626e+05 |
| power-capped share of samples | 0.7208 | 0.7219 | 0.7205 |

## Total: Omni governs against native, 10 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.2 | 40.25 | +0.1% | -0.2412 to +0.3373 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.616e+05 | 1.614e+05 | -0.1% | -1351 to +974.7 | EVEN, under the floor |
| energy per served request (J) | 24.88 | 24.85 | -0.1% | -0.2081 to +0.1501 | EVEN, under the floor |
| power, GPU mean (W) | 255.5 | 255.2 | -0.1% | -2.141 to +1.54 | EVEN, under the floor |
| requests served | 6494 | 6494 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 86.88 | 86.72 | -0.2% | -0.5257 to +0.2034 | EVEN, under the floor |
| response time, 95th percentile (ms) | 253.4 | 253.3 | -0.0% | -1.594 to +1.348 | EVEN, under the floor |
| response time, 99th percentile (ms) | 442.7 | 441.6 | -0.3% | -4.009 to +1.709 | EVEN, under the floor |
| temperature, peak (C) | 76.3 | 75.9 | -0.5% | -1.423 to +0.6228 | GAIN, not beyond the noise |
| temperature, mean (C) | 62.48 | 62.28 | -0.3% | -0.9042 to +0.4902 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.626e+05 | 1.626e+05 | -0.0% | -467.3 to +336.4 | EVEN, under the floor |
| power-capped share of samples | 0.7208 | 0.7205 | -0.0% | -0.005951 to +0.005411 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 10 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.2 | 40.09 | -0.3% | -0.4177 to +0.2069 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.616e+05 | 1.62e+05 | +0.3% | -834.5 to +1686 | EVEN, under the floor |
| energy per served request (J) | 24.88 | 24.94 | +0.3% | -0.1285 to +0.2596 | EVEN, under the floor |
| power, GPU mean (W) | 255.5 | 256.2 | +0.3% | -1.318 to +2.655 | EVEN, under the floor |
| requests served | 6494 | 6494 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 86.88 | 86.76 | -0.1% | -0.5003 to +0.2561 | EVEN, under the floor |
| response time, 95th percentile (ms) | 253.4 | 253.1 | -0.1% | -2.184 to +1.503 | EVEN, under the floor |
| response time, 99th percentile (ms) | 442.7 | 442.8 | +0.0% | -4.348 to +4.449 | EVEN, under the floor |
| temperature, peak (C) | 76.3 | 76 | -0.4% | -1.518 to +0.9181 | EVEN, under the floor |
| temperature, mean (C) | 62.48 | 62.16 | -0.5% | -0.9977 to +0.3611 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.626e+05 | 1.625e+05 | -0.1% | -543.7 to +296.2 | EVEN, under the floor |
| power-capped share of samples | 0.7208 | 0.7219 | +0.2% | -0.006209 to +0.008493 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 10 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.09 | 40.25 | +0.4% | -0.1539 to +0.4607 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.62e+05 | 1.614e+05 | -0.4% | -1850 to +622 | EVEN, under the floor |
| energy per served request (J) | 24.94 | 24.85 | -0.4% | -0.2849 to +0.09578 | EVEN, under the floor |
| power, GPU mean (W) | 256.2 | 255.2 | -0.4% | -2.925 to +0.9869 | EVEN, under the floor |
| requests served | 6494 | 6494 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 86.76 | 86.72 | -0.0% | -0.5432 to +0.4651 | EVEN, under the floor |
| response time, 95th percentile (ms) | 253.1 | 253.3 | +0.1% | -2.154 to +2.589 | EVEN, under the floor |
| response time, 99th percentile (ms) | 442.8 | 441.6 | -0.3% | -6.227 to +3.826 | EVEN, under the floor |
| temperature, peak (C) | 76 | 75.9 | -0.1% | -1.509 to +1.309 | EVEN, under the floor |
| temperature, mean (C) | 62.16 | 62.28 | +0.2% | -0.8723 to +1.095 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.625e+05 | 1.626e+05 | +0.0% | -490.1 to +606.7 | EVEN, under the floor |
| power-capped share of samples | 0.7219 | 0.7205 | -0.2% | -0.005809 to +0.002985 | EVEN, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 40.2 -> 40.25 served requests per kJ, difference +0.04804 (95% interval -0.2412 to +0.3373).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): EVEN, under the floor.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| omni | 2 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| omni | 3 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| omni | 4 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| omni | 5 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| omni | 6 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| omni | 7 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| omni | 8 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| omni | 9 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| omni | 10 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 1 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 2 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 3 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 4 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 5 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 6 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 7 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 8 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 9 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 10 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*