# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 8e62252e1f28; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 38.65 | 38.79 | 38.4 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 5.037e+04 | 5.02e+04 | 5.07e+04 |
| energy per served request (J) | 25.87 | 25.78 | 26.04 |
| power, GPU mean (W) | 237.2 | 236.4 | 238.7 |
| requests served | 1947 | 1947 | 1947 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 95.62 | 95.95 | 95.99 |
| response time, 95th percentile (ms) | 305.3 | 307.9 | 307 |
| response time, 99th percentile (ms) | 507.4 | 508.9 | 510 |
| temperature, peak (C) | 73.33 | 73 | 73 |
| temperature, mean (C) | 59.31 | 59.59 | 59.62 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 5.039e+04 | 5.045e+04 | 5.049e+04 |
| power-capped share of samples | 0.6468 | 0.6487 | 0.6464 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.65 | 38.4 | -0.7% | -0.9387 to +0.4319 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.037e+04 | 5.07e+04 | +0.7% | -563.8 to +1227 | power given, not beyond the noise |
| energy per served request (J) | 25.87 | 26.04 | +0.7% | -0.2896 to +0.6301 | power given, not beyond the noise |
| power, GPU mean (W) | 237.2 | 238.7 | +0.7% | -2.734 to +5.872 | power given, not beyond the noise |
| requests served | 1947 | 1947 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 95.62 | 95.99 | +0.4% | -0.2428 to +0.993 | EVEN, under the floor |
| response time, 95th percentile (ms) | 305.3 | 307 | +0.5% | -4.625 to +7.884 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 507.4 | 510 | +0.5% | -4.448 to +9.561 | LOSS, not beyond the noise |
| temperature, peak (C) | 73.33 | 73 | -0.5% | -1.768 to +1.101 | EVEN, under the floor |
| temperature, mean (C) | 59.31 | 59.62 | +0.5% | -0.9933 to +1.62 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 5.039e+04 | 5.049e+04 | +0.2% | -290.6 to +500.1 | EVEN, under the floor |
| power-capped share of samples | 0.6468 | 0.6464 | -0.1% | -0.04048 to +0.03977 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.65 | 38.79 | +0.4% | -1.097 to +1.378 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.037e+04 | 5.02e+04 | -0.3% | -1749 to +1403 | EVEN, under the floor |
| energy per served request (J) | 25.87 | 25.78 | -0.3% | -0.8984 to +0.7208 | EVEN, under the floor |
| power, GPU mean (W) | 237.2 | 236.4 | -0.3% | -8.179 to +6.61 | EVEN, under the floor |
| requests served | 1947 | 1947 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 95.62 | 95.95 | +0.4% | -0.2142 to +0.8844 | EVEN, under the floor |
| response time, 95th percentile (ms) | 305.3 | 307.9 | +0.9% | -3.162 to +8.355 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 507.4 | 508.9 | +0.3% | -3.247 to +6.248 | EVEN, under the floor |
| temperature, peak (C) | 73.33 | 73 | -0.5% | -1.768 to +1.101 | EVEN, under the floor |
| temperature, mean (C) | 59.31 | 59.59 | +0.5% | -0.9096 to +1.481 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 5.039e+04 | 5.045e+04 | +0.1% | -325.6 to +450.1 | EVEN, under the floor |
| power-capped share of samples | 0.6468 | 0.6487 | +0.3% | -0.01305 to +0.01685 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.79 | 38.4 | -1.0% | -2.31 to +1.523 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.02e+04 | 5.07e+04 | +1.0% | -1959 to +2968 | power given, not beyond the noise |
| energy per served request (J) | 25.78 | 26.04 | +1.0% | -1.006 to +1.524 | power given, not beyond the noise |
| power, GPU mean (W) | 236.4 | 238.7 | +1.0% | -9.301 to +14.01 | power given, not beyond the noise |
| requests served | 1947 | 1947 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 95.95 | 95.99 | +0.0% | -0.107 to +0.187 | EVEN, under the floor |
| response time, 95th percentile (ms) | 307.9 | 307 | -0.3% | -1.525 to -0.4083 | EVEN, under the floor |
| response time, 99th percentile (ms) | 508.9 | 510 | +0.2% | -2.068 to +4.181 | EVEN, under the floor |
| temperature, peak (C) | 73 | 73 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 59.59 | 59.62 | +0.0% | -0.1823 to +0.2376 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 5.045e+04 | 5.049e+04 | +0.1% | -245.3 to +330.3 | EVEN, under the floor |
| power-capped share of samples | 0.6487 | 0.6464 | -0.3% | -0.04181 to +0.0373 | EVEN, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 38.65 -> 38.4 served requests per kJ, difference -0.2534 (95% interval -0.9387 to +0.4319).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 2 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*