# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
5 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 44.74 | 44.61 | 44.84 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.337e+04 | 6.356e+04 | 6.324e+04 |
| energy per served request (J) | 22.35 | 22.42 | 22.31 |
| power, GPU mean (W) | 190.3 | 190.9 | 190 |
| requests served | 2835 | 2835 | 2835 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 100.1 | 99.03 | 100 |
| response time, 95th percentile (ms) | 311.5 | 305.2 | 307.8 |
| response time, 99th percentile (ms) | 553 | 544.1 | 551.6 |
| temperature, peak (C) | 67.8 | 67 | 67.6 |
| temperature, mean (C) | 58.27 | 57.17 | 58.07 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.373e+04 | 6.34e+04 | 6.342e+04 |
| power-capped share of samples | 0.6727 | 0.6666 | 0.653 |

## Total: Omni governs against native, 5 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.74 | 44.84 | +0.2% | -0.6694 to +0.8614 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.337e+04 | 6.324e+04 | -0.2% | -1217 to +943.9 | EVEN, under the floor |
| energy per served request (J) | 22.35 | 22.31 | -0.2% | -0.4294 to +0.3329 | EVEN, under the floor |
| power, GPU mean (W) | 190.3 | 190 | -0.1% | -3.612 to +3.094 | EVEN, under the floor |
| requests served | 2835 | 2835 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 100.1 | 100 | -0.1% | -1.36 to +1.224 | EVEN, under the floor |
| response time, 95th percentile (ms) | 311.5 | 307.8 | -1.2% | -13.69 to +6.202 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 553 | 551.6 | -0.3% | -15.54 to +12.72 | EVEN, under the floor |
| temperature, peak (C) | 67.8 | 67.6 | -0.3% | -2.588 to +2.188 | EVEN, under the floor |
| temperature, mean (C) | 58.27 | 58.07 | -0.3% | -1.249 to +0.8493 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.373e+04 | 6.342e+04 | -0.5% | -713.4 to +94.19 | EVEN, under the floor |
| power-capped share of samples | 0.6727 | 0.653 | -2.9% | -0.04611 to +0.006604 | LOSS, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 5 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.74 | 44.61 | -0.3% | -0.9242 to +0.669 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.337e+04 | 6.356e+04 | +0.3% | -929.4 to +1303 | EVEN, under the floor |
| energy per served request (J) | 22.35 | 22.42 | +0.3% | -0.3278 to +0.4596 | EVEN, under the floor |
| power, GPU mean (W) | 190.3 | 190.9 | +0.3% | -2.768 to +4.073 | EVEN, under the floor |
| requests served | 2835 | 2835 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 100.1 | 99.03 | -1.0% | -2.779 to +0.6879 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 311.5 | 305.2 | -2.0% | -16.8 to +4.16 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 553 | 544.1 | -1.6% | -23.29 to +5.458 | GAIN, not beyond the noise |
| temperature, peak (C) | 67.8 | 67 | -1.2% | -2.16 to +0.56 | GAIN, not beyond the noise |
| temperature, mean (C) | 58.27 | 57.17 | -1.9% | -2.751 to +0.5445 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.373e+04 | 6.34e+04 | -0.5% | -589.1 to -62.47 | GAIN, clear of the noise |
| power-capped share of samples | 0.6727 | 0.6666 | -0.9% | -0.01904 to +0.006795 | LOSS, not beyond the noise |

## Authority: Omni governs against Omni watching, 5 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.61 | 44.84 | +0.5% | -0.4966 to +0.9438 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.356e+04 | 6.324e+04 | -0.5% | -1345 to +697.8 | GAIN, not beyond the noise |
| energy per served request (J) | 22.42 | 22.31 | -0.5% | -0.4744 to +0.2461 | GAIN, not beyond the noise |
| power, GPU mean (W) | 190.9 | 190 | -0.5% | -4.047 to +2.224 | EVEN, under the floor |
| requests served | 2835 | 2835 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 99.03 | 100 | +1.0% | +0.2469 to +1.707 | LOSS, clear of the noise |
| response time, 95th percentile (ms) | 305.2 | 307.8 | +0.8% | -0.6311 to +5.779 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 544.1 | 551.6 | +1.4% | +1.953 to +13.06 | LOSS, clear of the noise |
| temperature, peak (C) | 67 | 67.6 | +0.9% | -0.5104 to +1.71 | power given, not beyond the noise |
| temperature, mean (C) | 57.17 | 58.07 | +1.6% | -0.1236 to +1.931 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.34e+04 | 6.342e+04 | +0.0% | -167.5 to +199.8 | EVEN, under the floor |
| power-capped share of samples | 0.6666 | 0.653 | -2.0% | -0.04048 to +0.01322 | LOSS, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 44.74 -> 44.84 served requests per kJ, difference +0.096 (95% interval -0.6694 to +0.8614).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 2 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 3 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 4 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| omni | 5 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 1 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 2 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 3 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 4 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 5 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 56.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*