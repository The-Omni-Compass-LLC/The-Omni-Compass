# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
5 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 68.23 | 68.11 | 68.38 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.229e+04 | 9.233e+04 | 9.21e+04 |
| energy per served request (J) | 14.66 | 14.68 | 14.62 |
| power, GPU mean (W) | 277.4 | 277.3 | 276.7 |
| requests served | 6296 | 6289 | 6298 |
| requests not served | 1208 | 1215 | 1206 |
| response time, mean (ms) | 3.866e+04 | 3.896e+04 | 3.87e+04 |
| response time, 95th percentile (ms) | 7.3e+04 | 7.331e+04 | 7.304e+04 |
| response time, 99th percentile (ms) | 7.59e+04 | 7.618e+04 | 7.588e+04 |
| temperature, peak (C) | 65.8 | 66.4 | 65.6 |
| temperature, mean (C) | 62.89 | 63.33 | 62.07 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.23e+04 | 9.232e+04 | 9.208e+04 |
| power-capped share of samples | 0.9914 | 0.9913 | 0.7395 |

## Total: Omni governs against native, 5 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 68.23 | 68.38 | +0.2% | -0.4582 to +0.7754 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.229e+04 | 9.21e+04 | -0.2% | -714.5 to +335.7 | EVEN, under the floor |
| energy per served request (J) | 14.66 | 14.62 | -0.2% | -0.1661 to +0.09836 | EVEN, under the floor |
| power, GPU mean (W) | 277.4 | 276.7 | -0.3% | -2.28 to +0.8826 | EVEN, under the floor |
| requests served | 6296 | 6298 | +0.0% | -22.05 to +25.25 | EVEN, under the floor |
| requests not served | 1208 | 1206 | -0.1% | -25.25 to +22.05 | EVEN, under the floor |
| response time, mean (ms) | 3.866e+04 | 3.87e+04 | +0.1% | -569.8 to +664.2 | EVEN, under the floor |
| response time, 95th percentile (ms) | 7.3e+04 | 7.304e+04 | +0.1% | -819.8 to +901.7 | EVEN, under the floor |
| response time, 99th percentile (ms) | 7.59e+04 | 7.588e+04 | -0.0% | -818.5 to +779.1 | EVEN, under the floor |
| temperature, peak (C) | 65.8 | 65.6 | -0.3% | -2.891 to +2.491 | EVEN, under the floor |
| temperature, mean (C) | 62.89 | 62.07 | -1.3% | -4.478 to +2.832 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.23e+04 | 9.208e+04 | -0.2% | -757.3 to +314.9 | EVEN, under the floor |
| power-capped share of samples | 0.9914 | 0.7395 | -25.4% | -0.6838 to +0.1799 | LOSS, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 5 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 68.23 | 68.11 | -0.2% | -0.4046 to +0.1819 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.229e+04 | 9.233e+04 | +0.0% | -30.23 to +114.7 | EVEN, under the floor |
| energy per served request (J) | 14.66 | 14.68 | +0.2% | -0.03926 to +0.0874 | EVEN, under the floor |
| power, GPU mean (W) | 277.4 | 277.3 | -0.0% | -0.4182 to +0.3822 | EVEN, under the floor |
| requests served | 6296 | 6289 | -0.1% | -30.9 to +16.1 | EVEN, under the floor |
| requests not served | 1208 | 1215 | +0.6% | -16.1 to +30.9 | LOSS, not beyond the noise |
| response time, mean (ms) | 3.866e+04 | 3.896e+04 | +0.8% | -235 to +846.3 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.3e+04 | 7.331e+04 | +0.4% | -612.8 to +1223 | EVEN, under the floor |
| response time, 99th percentile (ms) | 7.59e+04 | 7.618e+04 | +0.4% | -585 to +1143 | EVEN, under the floor |
| temperature, peak (C) | 65.8 | 66.4 | +0.9% | -1.477 to +2.677 | power given, not beyond the noise |
| temperature, mean (C) | 62.89 | 63.33 | +0.7% | -1.554 to +2.432 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.23e+04 | 9.232e+04 | +0.0% | -4.482 to +39.53 | EVEN, under the floor |
| power-capped share of samples | 0.9914 | 0.9913 | -0.0% | -0.001444 to +0.001213 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 5 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 68.11 | 68.38 | +0.4% | -0.4706 to +1.01 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.233e+04 | 9.21e+04 | -0.3% | -742.4 to +279.2 | EVEN, under the floor |
| energy per served request (J) | 14.68 | 14.62 | -0.4% | -0.2172 to +0.1014 | EVEN, under the floor |
| power, GPU mean (W) | 277.3 | 276.7 | -0.2% | -2.479 to +1.118 | EVEN, under the floor |
| requests served | 6289 | 6298 | +0.1% | -25.97 to +43.97 | EVEN, under the floor |
| requests not served | 1215 | 1206 | -0.7% | -43.97 to +25.97 | GAIN, not beyond the noise |
| response time, mean (ms) | 3.896e+04 | 3.87e+04 | -0.7% | -398.5 to -118.4 | GAIN, clear of the noise |
| response time, 95th percentile (ms) | 7.331e+04 | 7.304e+04 | -0.4% | -1344 to +815.4 | EVEN, under the floor |
| response time, 99th percentile (ms) | 7.618e+04 | 7.588e+04 | -0.4% | -1467 to +870.6 | EVEN, under the floor |
| temperature, peak (C) | 66.4 | 65.6 | -1.2% | -5.224 to +3.624 | GAIN, not beyond the noise |
| temperature, mean (C) | 63.33 | 62.07 | -2.0% | -5.273 to +2.748 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.232e+04 | 9.208e+04 | -0.3% | -771.5 to +294.1 | EVEN, under the floor |
| power-capped share of samples | 0.9913 | 0.7395 | -25.4% | -0.6838 to +0.1802 | LOSS, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 68.23 -> 68.38 served requests per kJ, difference +0.1586 (95% interval -0.4582 to +0.7754).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): EVEN, under the floor.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| omni | 2 | 159 | 0 | n/a | n/a | 0 | 159 | 0 |
| omni | 3 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| omni | 4 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| omni | 5 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| watch | 1 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| watch | 2 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| watch | 3 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| watch | 4 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| watch | 5 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 54.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*