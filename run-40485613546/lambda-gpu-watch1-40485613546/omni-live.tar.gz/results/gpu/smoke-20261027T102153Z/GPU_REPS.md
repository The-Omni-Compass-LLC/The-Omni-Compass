# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 39.15 | 39.18 | 38.7 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 5.029e+04 | 5.026e+04 | 5.087e+04 |
| energy per served request (J) | 25.54 | 25.52 | 25.84 |
| power, GPU mean (W) | 235.7 | 235.4 | 238.3 |
| requests served | 1969 | 1969 | 1969 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.36 | 96.5 | 96.46 |
| response time, 95th percentile (ms) | 306.9 | 308.3 | 307.1 |
| response time, 99th percentile (ms) | 512.1 | 512.1 | 513.1 |
| temperature, peak (C) | 80 | 80 | 79.67 |
| temperature, mean (C) | 63.97 | 63.95 | 64.22 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 5.041e+04 | 5.043e+04 | 5.05e+04 |
| power-capped share of samples | 0.6362 | 0.6285 | 0.639 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.15 | 38.7 | -1.1% | -1.262 to +0.362 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.029e+04 | 5.087e+04 | +1.2% | -467.4 to +1636 | power given, not beyond the noise |
| energy per served request (J) | 25.54 | 25.84 | +1.2% | -0.2374 to +0.8308 | power given, not beyond the noise |
| power, GPU mean (W) | 235.7 | 238.3 | +1.1% | -2.133 to +7.295 | power given, not beyond the noise |
| requests served | 1969 | 1969 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 96.36 | 96.46 | +0.1% | -0.7417 to +0.9386 | EVEN, under the floor |
| response time, 95th percentile (ms) | 306.9 | 307.1 | +0.1% | -3.195 to +3.507 | EVEN, under the floor |
| response time, 99th percentile (ms) | 512.1 | 513.1 | +0.2% | -6.797 to +8.736 | EVEN, under the floor |
| temperature, peak (C) | 80 | 79.67 | -0.4% | -1.768 to +1.101 | EVEN, under the floor |
| temperature, mean (C) | 63.97 | 64.22 | +0.4% | -0.995 to +1.499 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 5.041e+04 | 5.05e+04 | +0.2% | -194.9 to +379.2 | EVEN, under the floor |
| power-capped share of samples | 0.6362 | 0.639 | +0.5% | -0.05932 to +0.06505 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.15 | 39.18 | +0.1% | -1.45 to +1.509 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.029e+04 | 5.026e+04 | -0.1% | -1939 to +1876 | EVEN, under the floor |
| energy per served request (J) | 25.54 | 25.52 | -0.1% | -0.9846 to +0.9525 | EVEN, under the floor |
| power, GPU mean (W) | 235.7 | 235.4 | -0.1% | -8.981 to +8.384 | EVEN, under the floor |
| requests served | 1969 | 1969 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 96.36 | 96.5 | +0.1% | -1.176 to +1.461 | EVEN, under the floor |
| response time, 95th percentile (ms) | 306.9 | 308.3 | +0.5% | -3.398 to +6.263 | EVEN, under the floor |
| response time, 99th percentile (ms) | 512.1 | 512.1 | +0.0% | -5.973 to +6.007 | EVEN, under the floor |
| temperature, peak (C) | 80 | 80 | +0.0% | -2.484 to +2.484 | EVEN, under the floor |
| temperature, mean (C) | 63.97 | 63.95 | -0.0% | -1.408 to +1.354 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 5.041e+04 | 5.043e+04 | +0.0% | -239.9 to +290 | EVEN, under the floor |
| power-capped share of samples | 0.6362 | 0.6285 | -1.2% | -0.02104 to +0.005744 | LOSS, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.18 | 38.7 | -1.2% | -1.476 to +0.5175 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.026e+04 | 5.087e+04 | +1.2% | -663.2 to +1895 | power given, not beyond the noise |
| energy per served request (J) | 25.52 | 25.84 | +1.2% | -0.3368 to +0.9623 | power given, not beyond the noise |
| power, GPU mean (W) | 235.4 | 238.3 | +1.2% | -3.201 to +8.96 | power given, not beyond the noise |
| requests served | 1969 | 1969 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 96.5 | 96.46 | -0.0% | -1.944 to +1.856 | EVEN, under the floor |
| response time, 95th percentile (ms) | 308.3 | 307.1 | -0.4% | -9.417 to +6.864 | EVEN, under the floor |
| response time, 99th percentile (ms) | 512.1 | 513.1 | +0.2% | -7.166 to +9.071 | EVEN, under the floor |
| temperature, peak (C) | 80 | 79.67 | -0.4% | -4.128 to +3.462 | EVEN, under the floor |
| temperature, mean (C) | 63.95 | 64.22 | +0.4% | -1.168 to +1.725 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 5.043e+04 | 5.05e+04 | +0.1% | -31.15 to +165.4 | EVEN, under the floor |
| power-capped share of samples | 0.6285 | 0.639 | +1.7% | -0.03908 to +0.06011 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 39.15 -> 38.7 served requests per kJ, difference -0.4499 (95% interval -1.262 to +0.362).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 2 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 2 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*