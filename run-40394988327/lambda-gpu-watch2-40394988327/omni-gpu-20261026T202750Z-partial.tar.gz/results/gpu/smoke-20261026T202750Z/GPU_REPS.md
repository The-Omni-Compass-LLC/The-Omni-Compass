# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 8e62252e1f28; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 55.15 | 55.69 | 55.41 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.201e+04 | 2.18e+04 | 2.191e+04 |
| energy per served request (J) | 18.13 | 17.96 | 18.05 |
| power, GPU mean (W) | 104 | 103 | 103.5 |
| requests served | 1214 | 1214 | 1214 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 148.7 | 149.6 | 149.4 |
| response time, 95th percentile (ms) | 524.1 | 522 | 511.4 |
| response time, 99th percentile (ms) | 756.4 | 757.1 | 754.2 |
| temperature, peak (C) | 63.67 | 64 | 64 |
| temperature, mean (C) | 56.3 | 57.17 | 57.27 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.188e+04 | 2.192e+04 | 2.195e+04 |
| power-capped share of samples | 0.7964 | 0.7932 | 0.8011 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 55.15 | 55.41 | +0.5% | -0.6082 to +1.13 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.201e+04 | 2.191e+04 | -0.5% | -446.6 to +240.3 | EVEN, under the floor |
| energy per served request (J) | 18.13 | 18.05 | -0.5% | -0.3679 to +0.1979 | EVEN, under the floor |
| power, GPU mean (W) | 104 | 103.5 | -0.5% | -2.125 to +1.133 | EVEN, under the floor |
| requests served | 1214 | 1214 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 148.7 | 149.4 | +0.4% | -6.483 to +7.765 | EVEN, under the floor |
| response time, 95th percentile (ms) | 524.1 | 511.4 | -2.4% | -51.3 to +26 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 756.4 | 754.2 | -0.3% | -23.26 to +18.91 | EVEN, under the floor |
| temperature, peak (C) | 63.67 | 64 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 56.3 | 57.27 | +1.7% | -3.222 to +5.174 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.188e+04 | 2.195e+04 | +0.3% | -226.9 to +362.6 | EVEN, under the floor |
| power-capped share of samples | 0.7964 | 0.8011 | +0.6% | -0.007714 to +0.01718 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 55.15 | 55.69 | +1.0% | +0.3926 to +0.6969 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.201e+04 | 2.18e+04 | -1.0% | -276.7 to -154 | GAIN, clear of the noise |
| energy per served request (J) | 18.13 | 17.96 | -1.0% | -0.2279 to -0.1268 | GAIN, clear of the noise |
| power, GPU mean (W) | 104 | 103 | -1.0% | -1.324 to -0.719 | GAIN, clear of the noise |
| requests served | 1214 | 1214 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 148.7 | 149.6 | +0.5% | -3.861 to +5.49 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 524.1 | 522 | -0.4% | -29.52 to +25.34 | EVEN, under the floor |
| response time, 99th percentile (ms) | 756.4 | 757.1 | +0.1% | -25.97 to +27.27 | EVEN, under the floor |
| temperature, peak (C) | 63.67 | 64 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 56.3 | 57.17 | +1.6% | -3.057 to +4.809 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.188e+04 | 2.192e+04 | +0.2% | -220.9 to +297.4 | EVEN, under the floor |
| power-capped share of samples | 0.7964 | 0.7932 | -0.4% | -0.00675 to +0.0004371 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 55.69 | 55.41 | -0.5% | -1.058 to +0.4901 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.18e+04 | 2.191e+04 | +0.5% | -193.2 to +417.5 | power given, not beyond the noise |
| energy per served request (J) | 17.96 | 18.05 | +0.5% | -0.1591 to +0.3439 | power given, not beyond the noise |
| power, GPU mean (W) | 103 | 103.5 | +0.5% | -0.9097 to +1.96 | power given, not beyond the noise |
| requests served | 1214 | 1214 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 149.6 | 149.4 | -0.1% | -2.623 to +2.274 | EVEN, under the floor |
| response time, 95th percentile (ms) | 522 | 511.4 | -2.0% | -37.83 to +16.72 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 757.1 | 754.2 | -0.4% | -16.18 to +10.52 | EVEN, under the floor |
| temperature, peak (C) | 64 | 64 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 57.17 | 57.27 | +0.2% | -0.1689 to +0.3691 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.192e+04 | 2.195e+04 | +0.1% | -9.539 to +68.78 | EVEN, under the floor |
| power-capped share of samples | 0.7932 | 0.8011 | +1.0% | -0.003714 to +0.0195 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 55.15 -> 55.41 served requests per kJ, difference +0.2607 (95% interval -0.6082 to +1.13).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, clear of the noise. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: NOT ATTRIBUTABLE: WATCH DIFFERS FROM NATIVE.**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*