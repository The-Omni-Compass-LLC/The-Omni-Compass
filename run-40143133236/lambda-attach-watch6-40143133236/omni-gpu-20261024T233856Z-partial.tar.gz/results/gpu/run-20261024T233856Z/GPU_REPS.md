# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 580.105.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
10 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit cafb516b0fb8; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 54.36 | 54.42 | 54.34 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.888e+04 | 6.88e+04 | 6.891e+04 |
| energy per served request (J) | 18.4 | 18.38 | 18.4 |
| power, GPU mean (W) | 109 | 108.9 | 109 |
| requests served | 3744 | 3744 | 3744 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 158.6 | 158.6 | 158.7 |
| response time, 95th percentile (ms) | 494.6 | 493.5 | 495 |
| response time, 99th percentile (ms) | 1106 | 1106 | 1107 |
| temperature, peak (C) | 70.5 | 70.4 | 70.6 |
| temperature, mean (C) | 59.46 | 59.47 | 59.44 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.793e+04 | 6.793e+04 | 6.794e+04 |
| power-capped share of samples | 0.8648 | 0.8671 | 0.8642 |

## Total: Omni governs against native, 10 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 54.36 | 54.34 | -0.0% | -0.1863 to +0.1443 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.888e+04 | 6.891e+04 | +0.0% | -182.7 to +235.3 | EVEN, under the floor |
| energy per served request (J) | 18.4 | 18.4 | +0.0% | -0.04879 to +0.06284 | EVEN, under the floor |
| power, GPU mean (W) | 109 | 109 | +0.0% | -0.3197 to +0.3751 | EVEN, under the floor |
| requests served | 3744 | 3744 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 158.6 | 158.7 | +0.1% | -0.07765 to +0.4241 | EVEN, under the floor |
| response time, 95th percentile (ms) | 494.6 | 495 | +0.1% | -1.465 to +2.163 | EVEN, under the floor |
| response time, 99th percentile (ms) | 1106 | 1107 | +0.1% | -2.158 to +3.987 | EVEN, under the floor |
| temperature, peak (C) | 70.5 | 70.6 | +0.1% | -0.306 to +0.506 | EVEN, under the floor |
| temperature, mean (C) | 59.46 | 59.44 | -0.0% | -0.07056 to +0.02933 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.793e+04 | 6.794e+04 | +0.0% | -47.29 to +60.35 | EVEN, under the floor |
| power-capped share of samples | 0.8648 | 0.8642 | -0.1% | -0.002316 to +0.001162 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 10 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 54.36 | 54.42 | +0.1% | -0.1308 to +0.2599 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.888e+04 | 6.88e+04 | -0.1% | -328.9 to +165.4 | EVEN, under the floor |
| energy per served request (J) | 18.4 | 18.38 | -0.1% | -0.08785 to +0.04417 | EVEN, under the floor |
| power, GPU mean (W) | 109 | 108.9 | -0.1% | -0.4901 to +0.2637 | EVEN, under the floor |
| requests served | 3744 | 3744 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 158.6 | 158.6 | +0.0% | -0.3383 to +0.4441 | EVEN, under the floor |
| response time, 95th percentile (ms) | 494.6 | 493.5 | -0.2% | -3.407 to +1.123 | EVEN, under the floor |
| response time, 99th percentile (ms) | 1106 | 1106 | -0.0% | -3.103 to +2.024 | EVEN, under the floor |
| temperature, peak (C) | 70.5 | 70.4 | -0.1% | -0.506 to +0.306 | EVEN, under the floor |
| temperature, mean (C) | 59.46 | 59.47 | +0.0% | -0.03484 to +0.03869 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.793e+04 | 6.793e+04 | -0.0% | -31.19 to +19.54 | EVEN, under the floor |
| power-capped share of samples | 0.8648 | 0.8671 | +0.3% | +0.0008555 to +0.003799 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 10 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 54.42 | 54.34 | -0.2% | -0.3079 to +0.1369 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.88e+04 | 6.891e+04 | +0.2% | -173.3 to +389.4 | EVEN, under the floor |
| energy per served request (J) | 18.38 | 18.4 | +0.2% | -0.04628 to +0.104 | EVEN, under the floor |
| power, GPU mean (W) | 108.9 | 109 | +0.1% | -0.3132 to +0.595 | EVEN, under the floor |
| requests served | 3744 | 3744 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 158.6 | 158.7 | +0.1% | -0.2259 to +0.4665 | EVEN, under the floor |
| response time, 95th percentile (ms) | 493.5 | 495 | +0.3% | -0.5405 to +3.524 | EVEN, under the floor |
| response time, 99th percentile (ms) | 1106 | 1107 | +0.1% | -1.001 to +3.909 | EVEN, under the floor |
| temperature, peak (C) | 70.4 | 70.6 | +0.3% | -0.2524 to +0.6524 | EVEN, under the floor |
| temperature, mean (C) | 59.47 | 59.44 | -0.0% | -0.04232 to -0.002757 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.793e+04 | 6.794e+04 | +0.0% | -25.44 to +50.14 | EVEN, under the floor |
| power-capped share of samples | 0.8671 | 0.8642 | -0.3% | -0.004697 to -0.001112 | EVEN, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 54.36 -> 54.34 served requests per kJ, difference -0.02097 (95% interval -0.1863 to +0.1443).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): EVEN, under the floor.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| omni | 2 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| omni | 3 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| omni | 4 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| omni | 5 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| omni | 6 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| omni | 7 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| omni | 8 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| omni | 9 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| omni | 10 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| watch | 1 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| watch | 2 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| watch | 3 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| watch | 4 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| watch | 5 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| watch | 6 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| watch | 7 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| watch | 8 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| watch | 9 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| watch | 10 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*