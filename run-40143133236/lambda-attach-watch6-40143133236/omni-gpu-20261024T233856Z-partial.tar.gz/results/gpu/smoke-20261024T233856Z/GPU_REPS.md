# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 580.105.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit cafb516b0fb8; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 53.68 | 53.41 | 53.25 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.169e+04 | 2.18e+04 | 2.186e+04 |
| energy per served request (J) | 18.63 | 18.72 | 18.78 |
| power, GPU mean (W) | 102.4 | 102.9 | 103.3 |
| requests served | 1164 | 1164 | 1164 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 160.6 | 163.7 | 164 |
| response time, 95th percentile (ms) | 575.4 | 592.7 | 594.9 |
| response time, 99th percentile (ms) | 809.5 | 823.3 | 826 |
| temperature, peak (C) | 62.67 | 63 | 63 |
| temperature, mean (C) | 55.66 | 56.61 | 56.71 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.166e+04 | 2.175e+04 | 2.174e+04 |
| power-capped share of samples | 0.7828 | 0.7854 | 0.7847 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 53.68 | 53.25 | -0.8% | -1.743 to +0.8819 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.169e+04 | 2.186e+04 | +0.8% | -358.1 to +706.1 | power given, not beyond the noise |
| energy per served request (J) | 18.63 | 18.78 | +0.8% | -0.3077 to +0.6067 | power given, not beyond the noise |
| power, GPU mean (W) | 102.4 | 103.3 | +0.8% | -1.644 to +3.306 | power given, not beyond the noise |
| requests served | 1164 | 1164 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 160.6 | 164 | +2.1% | -11.13 to +18.03 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 575.4 | 594.9 | +3.4% | -71.39 to +110.3 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 809.5 | 826 | +2.0% | -47.83 to +80.75 | LOSS, not beyond the noise |
| temperature, peak (C) | 62.67 | 63 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 55.66 | 56.71 | +1.9% | -3.399 to +5.502 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.166e+04 | 2.174e+04 | +0.4% | -274.8 to +438.2 | EVEN, under the floor |
| power-capped share of samples | 0.7828 | 0.7847 | +0.2% | -0.004686 to +0.008338 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 53.68 | 53.41 | -0.5% | -2.04 to +1.502 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.169e+04 | 2.18e+04 | +0.5% | -610.9 to +827.1 | EVEN, under the floor |
| energy per served request (J) | 18.63 | 18.72 | +0.5% | -0.5248 to +0.7105 | EVEN, under the floor |
| power, GPU mean (W) | 102.4 | 102.9 | +0.5% | -2.85 to +3.877 | power given, not beyond the noise |
| requests served | 1164 | 1164 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 160.6 | 163.7 | +1.9% | -10.46 to +16.65 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 575.4 | 592.7 | +3.0% | -65.73 to +100.3 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 809.5 | 823.3 | +1.7% | -42.74 to +70.32 | LOSS, not beyond the noise |
| temperature, peak (C) | 62.67 | 63 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 55.66 | 56.61 | +1.7% | -3.187 to +5.095 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.166e+04 | 2.175e+04 | +0.4% | -268.7 to +461.6 | EVEN, under the floor |
| power-capped share of samples | 0.7828 | 0.7854 | +0.3% | -0.005037 to +0.01009 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 53.41 | 53.25 | -0.3% | -0.6577 to +0.3344 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.18e+04 | 2.186e+04 | +0.3% | -135.9 to +267.7 | EVEN, under the floor |
| energy per served request (J) | 18.72 | 18.78 | +0.3% | -0.1167 to +0.23 | EVEN, under the floor |
| power, GPU mean (W) | 102.9 | 103.3 | +0.3% | -0.6454 to +1.281 | EVEN, under the floor |
| requests served | 1164 | 1164 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 163.7 | 164 | +0.2% | -1.598 to +2.302 | EVEN, under the floor |
| response time, 95th percentile (ms) | 592.7 | 594.9 | +0.4% | -7.542 to +11.82 | EVEN, under the floor |
| response time, 99th percentile (ms) | 823.3 | 826 | +0.3% | -5.858 to +11.21 | EVEN, under the floor |
| temperature, peak (C) | 63 | 63 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 56.61 | 56.71 | +0.2% | -0.2163 to +0.4112 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.175e+04 | 2.174e+04 | -0.1% | -32.04 to +2.565 | EVEN, under the floor |
| power-capped share of samples | 0.7854 | 0.7847 | -0.1% | -0.001765 to +0.0003668 | EVEN, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 53.68 -> 53.25 served requests per kJ, difference -0.4305 (95% interval -1.743 to +0.8819).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): EVEN, under the floor.
**Result, by rule: EVEN (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*