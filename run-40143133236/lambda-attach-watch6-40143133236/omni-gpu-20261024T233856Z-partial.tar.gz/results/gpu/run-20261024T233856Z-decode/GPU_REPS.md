# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 580.105.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
10 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit cafb516b0fb8; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 79.83 | 79.78 | 79.79 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.959e+04 | 6.963e+04 | 6.962e+04 |
| energy per served request (J) | 12.53 | 12.53 | 12.53 |
| power, GPU mean (W) | 110.1 | 110.2 | 110.2 |
| requests served | 5555 | 5555 | 5555 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 101.1 | 101.1 | 101.1 |
| response time, 95th percentile (ms) | 285.7 | 285.7 | 285.4 |
| response time, 99th percentile (ms) | 489.6 | 490.3 | 490.5 |
| temperature, peak (C) | 69 | 69 | 69 |
| temperature, mean (C) | 59.85 | 59.85 | 59.84 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.919e+04 | 6.919e+04 | 6.916e+04 |
| power-capped share of samples | 0.9021 | 0.9012 | 0.9008 |

## Total: Omni governs against native, 10 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 79.83 | 79.79 | -0.1% | -0.1921 to +0.11 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.959e+04 | 6.962e+04 | +0.1% | -95.8 to +167.9 | EVEN, under the floor |
| energy per served request (J) | 12.53 | 12.53 | +0.1% | -0.01725 to +0.03022 | EVEN, under the floor |
| power, GPU mean (W) | 110.1 | 110.2 | +0.1% | -0.1586 to +0.2784 | EVEN, under the floor |
| requests served | 5555 | 5555 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 101.1 | 101.1 | -0.0% | -0.06032 to +0.01608 | EVEN, under the floor |
| response time, 95th percentile (ms) | 285.7 | 285.4 | -0.1% | -1.393 to +0.7038 | EVEN, under the floor |
| response time, 99th percentile (ms) | 489.6 | 490.5 | +0.2% | -0.199 to +1.989 | EVEN, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 59.85 | 59.84 | -0.0% | -0.07171 to +0.04878 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.919e+04 | 6.916e+04 | -0.0% | -70.18 to +24.98 | EVEN, under the floor |
| power-capped share of samples | 0.9021 | 0.9008 | -0.1% | -0.002993 to +0.0005054 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 10 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 79.83 | 79.78 | -0.1% | -0.1574 to +0.05679 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.959e+04 | 6.963e+04 | +0.1% | -49.48 to +137.6 | EVEN, under the floor |
| energy per served request (J) | 12.53 | 12.53 | +0.1% | -0.008908 to +0.02477 | EVEN, under the floor |
| power, GPU mean (W) | 110.1 | 110.2 | +0.1% | -0.08994 to +0.2049 | EVEN, under the floor |
| requests served | 5555 | 5555 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 101.1 | 101.1 | +0.0% | -0.04245 to +0.05836 | EVEN, under the floor |
| response time, 95th percentile (ms) | 285.7 | 285.7 | -0.0% | -1.488 to +1.452 | EVEN, under the floor |
| response time, 99th percentile (ms) | 489.6 | 490.3 | +0.1% | -0.5739 to +1.942 | EVEN, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 59.85 | 59.85 | -0.0% | -0.05299 to +0.04943 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.919e+04 | 6.919e+04 | +0.0% | -32.51 to +50.76 | EVEN, under the floor |
| power-capped share of samples | 0.9021 | 0.9012 | -0.1% | -0.002343 to +0.0006441 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 10 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 79.78 | 79.79 | +0.0% | -0.08834 to +0.1068 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.963e+04 | 6.962e+04 | -0.0% | -93.12 to +77.1 | EVEN, under the floor |
| energy per served request (J) | 12.53 | 12.53 | -0.0% | -0.01676 to +0.01388 | EVEN, under the floor |
| power, GPU mean (W) | 110.2 | 110.2 | +0.0% | -0.1601 to +0.165 | EVEN, under the floor |
| requests served | 5555 | 5555 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 101.1 | 101.1 | -0.0% | -0.07292 to +0.01276 | EVEN, under the floor |
| response time, 95th percentile (ms) | 285.7 | 285.4 | -0.1% | -1.713 to +1.059 | EVEN, under the floor |
| response time, 99th percentile (ms) | 490.3 | 490.5 | +0.0% | -0.4764 to +0.8988 | EVEN, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 59.85 | 59.84 | -0.0% | -0.04467 to +0.02529 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.919e+04 | 6.916e+04 | -0.0% | -96.87 to +33.43 | EVEN, under the floor |
| power-capped share of samples | 0.9012 | 0.9008 | -0.0% | -0.002215 to +0.001426 | EVEN, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 79.83 -> 79.79 served requests per kJ, difference -0.04107 (95% interval -0.1921 to +0.11).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): EVEN, under the floor.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| omni | 2 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| omni | 3 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| omni | 4 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| omni | 5 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| omni | 6 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| omni | 7 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| omni | 8 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| omni | 9 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| omni | 10 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| watch | 1 | 304 | 0 | n/a | n/a | 0 | 304 | 0 |
| watch | 2 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 3 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| watch | 4 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| watch | 5 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| watch | 6 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| watch | 7 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| watch | 8 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| watch | 9 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |
| watch | 10 | 307 | 0 | n/a | n/a | 0 | 307 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*