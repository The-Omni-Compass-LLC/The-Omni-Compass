# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit cafb516b0fb8; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 58.68 | 58.21 | 58.48 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.106e+04 | 2.123e+04 | 2.114e+04 |
| energy per served request (J) | 17.04 | 17.18 | 17.1 |
| power, GPU mean (W) | 99.48 | 100.3 | 99.83 |
| requests served | 1236 | 1236 | 1236 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 130 | 130.9 | 131.5 |
| response time, 95th percentile (ms) | 377.5 | 386.2 | 388.1 |
| response time, 99th percentile (ms) | 643.1 | 648.5 | 652.1 |
| temperature, peak (C) | 62 | 62.67 | 63 |
| temperature, mean (C) | 55.97 | 56.38 | 56.51 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.116e+04 | 2.117e+04 | 2.119e+04 |
| power-capped share of samples | 0.8027 | 0.8037 | 0.8037 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 58.68 | 58.48 | -0.4% | -1.467 to +1.051 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.106e+04 | 2.114e+04 | +0.4% | -379.8 to +530.5 | EVEN, under the floor |
| energy per served request (J) | 17.04 | 17.1 | +0.4% | -0.3073 to +0.4292 | EVEN, under the floor |
| power, GPU mean (W) | 99.48 | 99.83 | +0.4% | -1.794 to +2.492 | EVEN, under the floor |
| requests served | 1236 | 1236 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 130 | 131.5 | +1.1% | -0.8248 to +3.804 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 377.5 | 388.1 | +2.8% | -25.9 to +47.05 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 643.1 | 652.1 | +1.4% | -7.305 to +25.13 | LOSS, not beyond the noise |
| temperature, peak (C) | 62 | 63 | +1.6% | +1 to +1 | power given, clear of the noise |
| temperature, mean (C) | 55.97 | 56.51 | +1.0% | -1.039 to +2.132 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.116e+04 | 2.119e+04 | +0.1% | -0.145 to +52.1 | EVEN, under the floor |
| power-capped share of samples | 0.8027 | 0.8037 | +0.1% | -0.007535 to +0.009429 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 58.68 | 58.21 | -0.8% | -2.068 to +1.123 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.106e+04 | 2.123e+04 | +0.8% | -409.1 to +751.7 | power given, not beyond the noise |
| energy per served request (J) | 17.04 | 17.18 | +0.8% | -0.331 to +0.6082 | power given, not beyond the noise |
| power, GPU mean (W) | 99.48 | 100.3 | +0.8% | -1.938 to +3.548 | power given, not beyond the noise |
| requests served | 1236 | 1236 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 130 | 130.9 | +0.6% | -2.544 to +4.182 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 377.5 | 386.2 | +2.3% | -21.65 to +38.92 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 643.1 | 648.5 | +0.8% | -17.08 to +27.83 | LOSS, not beyond the noise |
| temperature, peak (C) | 62 | 62.67 | +1.1% | -0.7677 to +2.101 | power given, not beyond the noise |
| temperature, mean (C) | 55.97 | 56.38 | +0.7% | -1.249 to +2.08 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.116e+04 | 2.117e+04 | +0.0% | -69.13 to +86.4 | EVEN, under the floor |
| power-capped share of samples | 0.8027 | 0.8037 | +0.1% | -0.009834 to +0.01173 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 58.21 | 58.48 | +0.5% | -1.936 to +2.464 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.123e+04 | 2.114e+04 | -0.5% | -895.1 to +703.2 | EVEN, under the floor |
| energy per served request (J) | 17.18 | 17.1 | -0.5% | -0.7242 to +0.5689 | EVEN, under the floor |
| power, GPU mean (W) | 100.3 | 99.83 | -0.5% | -4.23 to +3.318 | EVEN, under the floor |
| requests served | 1236 | 1236 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 130.9 | 131.5 | +0.5% | -1.445 to +2.787 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 386.2 | 388.1 | +0.5% | -12.79 to +16.67 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 648.5 | 652.1 | +0.5% | -16.01 to +23.09 | LOSS, not beyond the noise |
| temperature, peak (C) | 62.67 | 63 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 56.38 | 56.51 | +0.2% | -0.1821 to +0.4447 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.117e+04 | 2.119e+04 | +0.1% | -42.84 to +77.53 | EVEN, under the floor |
| power-capped share of samples | 0.8037 | 0.8037 | +0.0% | -0.0131 to +0.0131 | EVEN, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 58.68 -> 58.48 served requests per kJ, difference -0.2081 (95% interval -1.467 to +1.051).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): EVEN, under the floor.
**Result, by rule: EVEN (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*