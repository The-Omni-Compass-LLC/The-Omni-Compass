# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit cafb516b0fb8; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 53.74 | 53.5 | 52.94 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.201e+04 | 2.211e+04 | 2.235e+04 |
| energy per served request (J) | 18.61 | 18.69 | 18.89 |
| power, GPU mean (W) | 104 | 104.4 | 105.5 |
| requests served | 1183 | 1183 | 1183 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 157.6 | 162.3 | 163.1 |
| response time, 95th percentile (ms) | 547.4 | 583 | 588 |
| response time, 99th percentile (ms) | 787.7 | 813.7 | 816.7 |
| temperature, peak (C) | 65.67 | 66 | 66 |
| temperature, mean (C) | 58.31 | 59.32 | 59.43 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.204e+04 | 2.214e+04 | 2.214e+04 |
| power-capped share of samples | 0.7869 | 0.7862 | 0.7878 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 53.74 | 52.94 | -1.5% | -0.9164 to -0.6895 | power given, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.201e+04 | 2.235e+04 | +1.5% | +290 to +377.6 | power given, clear of the noise |
| energy per served request (J) | 18.61 | 18.89 | +1.5% | +0.2451 to +0.3192 | power given, clear of the noise |
| power, GPU mean (W) | 104 | 105.5 | +1.5% | +1.342 to +1.816 | power given, clear of the noise |
| requests served | 1183 | 1183 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 157.6 | 163.1 | +3.4% | -16.96 to +27.82 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 547.4 | 588 | +7.4% | -127.7 to +209 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 787.7 | 816.7 | +3.7% | -94.91 to +152.8 | LOSS, not beyond the noise |
| temperature, peak (C) | 65.67 | 66 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 58.31 | 59.43 | +1.9% | -3.577 to +5.809 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.204e+04 | 2.214e+04 | +0.4% | -312.6 to +502.7 | EVEN, under the floor |
| power-capped share of samples | 0.7869 | 0.7878 | +0.1% | -0.003347 to +0.005107 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 53.74 | 53.5 | -0.5% | -1.543 to +1.056 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.201e+04 | 2.211e+04 | +0.5% | -437.8 to +640.3 | EVEN, under the floor |
| energy per served request (J) | 18.61 | 18.69 | +0.5% | -0.3701 to +0.5413 | EVEN, under the floor |
| power, GPU mean (W) | 104 | 104.4 | +0.5% | -2.041 to +3.002 | EVEN, under the floor |
| requests served | 1183 | 1183 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 157.6 | 162.3 | +3.0% | -13.63 to +23.01 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 547.4 | 583 | +6.5% | -103 to +174.1 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 787.7 | 813.7 | +3.3% | -80.53 to +132.6 | LOSS, not beyond the noise |
| temperature, peak (C) | 65.67 | 66 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 58.31 | 59.32 | +1.7% | -3.205 to +5.23 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.204e+04 | 2.214e+04 | +0.4% | -237.3 to +424.9 | EVEN, under the floor |
| power-capped share of samples | 0.7869 | 0.7862 | -0.1% | -0.001768 to +0.0003715 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 53.5 | 52.94 | -1.0% | -1.837 to +0.7186 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.211e+04 | 2.235e+04 | +1.1% | -299.2 to +764.3 | power given, not beyond the noise |
| energy per served request (J) | 18.69 | 18.89 | +1.1% | -0.2529 to +0.6461 | power given, not beyond the noise |
| power, GPU mean (W) | 104.4 | 105.5 | +1.1% | -1.405 to +3.602 | power given, not beyond the noise |
| requests served | 1183 | 1183 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 162.3 | 163.1 | +0.5% | -3.373 to +4.862 | EVEN, under the floor |
| response time, 95th percentile (ms) | 583 | 588 | +0.9% | -24.75 to +34.85 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 813.7 | 816.7 | +0.4% | -15.65 to +21.56 | EVEN, under the floor |
| temperature, peak (C) | 66 | 66 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 59.32 | 59.43 | +0.2% | -0.372 to +0.5793 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.214e+04 | 2.214e+04 | +0.0% | -93.31 to +95.9 | EVEN, under the floor |
| power-capped share of samples | 0.7862 | 0.7878 | +0.2% | -0.003224 to +0.00638 | EVEN, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 53.74 -> 52.94 served requests per kJ, difference -0.8029 (95% interval -0.9164 to -0.6895).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: LOSS.**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*