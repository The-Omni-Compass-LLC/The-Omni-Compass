# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit cafb516b0fb8; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 50.69 | 50.66 | 50.18 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.217e+04 | 2.219e+04 | 2.24e+04 |
| energy per served request (J) | 19.73 | 19.74 | 19.93 |
| power, GPU mean (W) | 104.6 | 104.7 | 105.7 |
| requests served | 1124 | 1124 | 1124 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 174.7 | 180.7 | 181.5 |
| response time, 95th percentile (ms) | 640.7 | 686.6 | 700.7 |
| response time, 99th percentile (ms) | 850.4 | 875.9 | 883.3 |
| temperature, peak (C) | 66.33 | 67 | 67 |
| temperature, mean (C) | 58.97 | 59.91 | 60.03 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.183e+04 | 2.191e+04 | 2.192e+04 |
| power-capped share of samples | 0.7837 | 0.785 | 0.7833 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 50.69 | 50.18 | -1.0% | -0.7175 to -0.3085 | power given, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.217e+04 | 2.24e+04 | +1.0% | +138.4 to +314.9 | power given, clear of the noise |
| energy per served request (J) | 19.73 | 19.93 | +1.0% | +0.1231 to +0.2802 | power given, clear of the noise |
| power, GPU mean (W) | 104.6 | 105.7 | +1.1% | +0.7628 to +1.452 | power given, clear of the noise |
| requests served | 1124 | 1124 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 174.7 | 181.5 | +3.9% | -17.65 to +31.25 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 640.7 | 700.7 | +9.4% | -102.1 to +222.1 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 850.4 | 883.3 | +3.9% | -102.5 to +168.3 | LOSS, not beyond the noise |
| temperature, peak (C) | 66.33 | 67 | +1.0% | -2.202 to +3.535 | power given, not beyond the noise |
| temperature, mean (C) | 58.97 | 60.03 | +1.8% | -3.48 to +5.607 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.183e+04 | 2.192e+04 | +0.4% | -341.3 to +532.6 | EVEN, under the floor |
| power-capped share of samples | 0.7837 | 0.7833 | -0.1% | -0.01433 to +0.01343 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 50.69 | 50.66 | -0.1% | -1.187 to +1.125 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.217e+04 | 2.219e+04 | +0.1% | -491.1 to +519.3 | EVEN, under the floor |
| energy per served request (J) | 19.73 | 19.74 | +0.1% | -0.437 to +0.462 | EVEN, under the floor |
| power, GPU mean (W) | 104.6 | 104.7 | +0.1% | -2.284 to +2.471 | EVEN, under the floor |
| requests served | 1124 | 1124 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 174.7 | 180.7 | +3.4% | -20.11 to +32.14 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 640.7 | 686.6 | +7.2% | -134.7 to +226.5 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 850.4 | 875.9 | +3.0% | -108.3 to +159.3 | LOSS, not beyond the noise |
| temperature, peak (C) | 66.33 | 67 | +1.0% | -2.202 to +3.535 | power given, not beyond the noise |
| temperature, mean (C) | 58.97 | 59.91 | +1.6% | -3.295 to +5.179 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.183e+04 | 2.191e+04 | +0.4% | -325.1 to +488 | EVEN, under the floor |
| power-capped share of samples | 0.7837 | 0.785 | +0.2% | -0.006289 to +0.008809 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 50.66 | 50.18 | -1.0% | -1.434 to +0.47 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.219e+04 | 2.24e+04 | +1.0% | -204.6 to +629.7 | power given, not beyond the noise |
| energy per served request (J) | 19.74 | 19.93 | +1.0% | -0.1821 to +0.5602 | power given, not beyond the noise |
| power, GPU mean (W) | 104.7 | 105.7 | +1.0% | -1.052 to +3.079 | power given, not beyond the noise |
| requests served | 1124 | 1124 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 180.7 | 181.5 | +0.4% | -3.581 to +5.154 | EVEN, under the floor |
| response time, 95th percentile (ms) | 686.6 | 700.7 | +2.1% | -22.98 to +51.18 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 875.9 | 883.3 | +0.8% | -19.65 to +34.47 | LOSS, not beyond the noise |
| temperature, peak (C) | 67 | 67 | +0.0% | +0 to +0 | EVEN, the same |
| temperature, mean (C) | 59.91 | 60.03 | +0.2% | -0.1915 to +0.435 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.191e+04 | 2.192e+04 | +0.1% | -17.1 to +45.45 | EVEN, under the floor |
| power-capped share of samples | 0.785 | 0.7833 | -0.2% | -0.01602 to +0.0126 | EVEN, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 50.69 -> 50.18 served requests per kJ, difference -0.513 (95% interval -0.7175 to -0.3085).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: LOSS.**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*