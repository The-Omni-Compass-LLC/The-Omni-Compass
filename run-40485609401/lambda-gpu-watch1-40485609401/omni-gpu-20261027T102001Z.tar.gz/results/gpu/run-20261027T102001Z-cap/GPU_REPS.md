# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
5 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 41.67 | 41.12 | 41.61 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.266e+04 | 6.351e+04 | 6.275e+04 |
| energy per served request (J) | 24 | 24.32 | 24.03 |
| power, GPU mean (W) | 188.4 | 191 | 188.7 |
| requests served | 2611 | 2611 | 2611 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 112.3 | 111.6 | 114.4 |
| response time, 95th percentile (ms) | 363.4 | 355.7 | 375.1 |
| response time, 99th percentile (ms) | 636.2 | 622.3 | 647.1 |
| temperature, peak (C) | 57.8 | 57.8 | 57.8 |
| temperature, mean (C) | 48.55 | 48.75 | 48.44 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.347e+04 | 6.345e+04 | 6.3e+04 |
| power-capped share of samples | 0.6642 | 0.6575 | 0.6232 |

## Total: Omni governs against native, 5 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.67 | 41.61 | -0.1% | -0.4116 to +0.2962 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.266e+04 | 6.275e+04 | +0.1% | -447.3 to +620 | EVEN, under the floor |
| energy per served request (J) | 24 | 24.03 | +0.1% | -0.1713 to +0.2375 | EVEN, under the floor |
| power, GPU mean (W) | 188.4 | 188.7 | +0.2% | -1.272 to +1.895 | EVEN, under the floor |
| requests served | 2611 | 2611 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 112.3 | 114.4 | +1.9% | -3.598 to +7.804 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 363.4 | 375.1 | +3.2% | -37.78 to +61.1 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 636.2 | 647.1 | +1.7% | -59.77 to +81.69 | LOSS, not beyond the noise |
| temperature, peak (C) | 57.8 | 57.8 | +0.0% | -1.241 to +1.241 | EVEN, under the floor |
| temperature, mean (C) | 48.55 | 48.44 | -0.2% | -0.2872 to +0.06347 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.347e+04 | 6.3e+04 | -0.7% | -519.7 to -409.6 | GAIN, clear of the noise |
| power-capped share of samples | 0.6642 | 0.6232 | -6.2% | -0.05415 to -0.02771 | LOSS, clear of the noise |

## Observation: omni watching (writes nothing) against native, 5 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.67 | 41.12 | -1.3% | -1.389 to +0.2786 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.266e+04 | 6.351e+04 | +1.4% | -421.7 to +2117 | power given, not beyond the noise |
| energy per served request (J) | 24 | 24.32 | +1.4% | -0.1615 to +0.8107 | power given, not beyond the noise |
| power, GPU mean (W) | 188.4 | 191 | +1.4% | -1.266 to +6.407 | power given, not beyond the noise |
| requests served | 2611 | 2611 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 112.3 | 111.6 | -0.7% | -3.22 to +1.689 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 363.4 | 355.7 | -2.1% | -30.45 to +15.05 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 636.2 | 622.3 | -2.2% | -51.01 to +23.22 | GAIN, not beyond the noise |
| temperature, peak (C) | 57.8 | 57.8 | +0.0% | -1.241 to +1.241 | EVEN, under the floor |
| temperature, mean (C) | 48.55 | 48.75 | +0.4% | -0.1907 to +0.5825 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.347e+04 | 6.345e+04 | -0.0% | -145.9 to +117.1 | EVEN, under the floor |
| power-capped share of samples | 0.6642 | 0.6575 | -1.0% | -0.01707 to +0.003833 | LOSS, not beyond the noise |

## Authority: Omni governs against Omni watching, 5 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.12 | 41.61 | +1.2% | -0.09477 to +1.09 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.351e+04 | 6.275e+04 | -1.2% | -1665 to +143.1 | GAIN, not beyond the noise |
| energy per served request (J) | 24.32 | 24.03 | -1.2% | -0.6378 to +0.05482 | GAIN, not beyond the noise |
| power, GPU mean (W) | 191 | 188.7 | -1.2% | -4.984 to +0.4674 | GAIN, not beyond the noise |
| requests served | 2611 | 2611 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 111.6 | 114.4 | +2.6% | -0.6063 to +6.343 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 355.7 | 375.1 | +5.4% | -8.196 to +46.91 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 622.3 | 647.1 | +4.0% | -9.611 to +59.32 | LOSS, not beyond the noise |
| temperature, peak (C) | 57.8 | 57.8 | +0.0% | -0.8778 to +0.8778 | EVEN, under the floor |
| temperature, mean (C) | 48.75 | 48.44 | -0.6% | -0.7607 to +0.1453 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.345e+04 | 6.3e+04 | -0.7% | -588.9 to -311.6 | GAIN, clear of the noise |
| power-capped share of samples | 0.6575 | 0.6232 | -5.2% | -0.05551 to -0.01311 | LOSS, clear of the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 41.67 -> 41.61 served requests per kJ, difference -0.05766 (95% interval -0.4116 to +0.2962).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: EVEN (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 2 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 3 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 4 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 5 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 1 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 2 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 3 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 4 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 5 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 78.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*