# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 37.34 | 37.64 | 38.38 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 5.011e+04 | 4.972e+04 | 4.876e+04 |
| energy per served request (J) | 26.79 | 26.57 | 26.06 |
| power, GPU mean (W) | 235.7 | 233.9 | 229.4 |
| requests served | 1871 | 1871 | 1871 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 90.1 | 90.15 | 90.31 |
| response time, 95th percentile (ms) | 276.3 | 278.6 | 277.8 |
| response time, 99th percentile (ms) | 508.6 | 510.3 | 509.5 |
| temperature, peak (C) | 68.33 | 68 | 67.67 |
| temperature, mean (C) | 53.43 | 53.21 | 53.27 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 4.974e+04 | 4.968e+04 | 4.969e+04 |
| power-capped share of samples | 0.6395 | 0.6407 | 0.6381 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 37.34 | 38.38 | +2.8% | -0.07349 to +2.147 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.011e+04 | 4.876e+04 | -2.7% | -2812 to +99.81 | GAIN, not beyond the noise |
| energy per served request (J) | 26.79 | 26.06 | -2.7% | -1.503 to +0.05334 | GAIN, not beyond the noise |
| power, GPU mean (W) | 235.7 | 229.4 | -2.7% | -13.06 to +0.4832 | GAIN, not beyond the noise |
| requests served | 1871 | 1871 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 90.1 | 90.31 | +0.2% | -0.05106 to +0.4581 | EVEN, under the floor |
| response time, 95th percentile (ms) | 276.3 | 277.8 | +0.6% | -1.012 to +4.122 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 508.6 | 509.5 | +0.2% | -1.238 to +3.019 | EVEN, under the floor |
| temperature, peak (C) | 68.33 | 67.67 | -1.0% | -2.101 to +0.7677 | GAIN, not beyond the noise |
| temperature, mean (C) | 53.43 | 53.27 | -0.3% | -0.4773 to +0.1553 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.974e+04 | 4.969e+04 | -0.1% | -295.7 to +196.4 | EVEN, under the floor |
| power-capped share of samples | 0.6395 | 0.6381 | -0.2% | -0.03431 to +0.03156 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 37.34 | 37.64 | +0.8% | -0.04908 to +0.6445 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.011e+04 | 4.972e+04 | -0.8% | -882.1 to +83.64 | GAIN, not beyond the noise |
| energy per served request (J) | 26.79 | 26.57 | -0.8% | -0.4714 to +0.04471 | GAIN, not beyond the noise |
| power, GPU mean (W) | 235.7 | 233.9 | -0.8% | -3.945 to +0.2213 | GAIN, not beyond the noise |
| requests served | 1871 | 1871 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 90.1 | 90.15 | +0.1% | -0.7732 to +0.8733 | EVEN, under the floor |
| response time, 95th percentile (ms) | 276.3 | 278.6 | +0.9% | -2.885 to +7.592 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 508.6 | 510.3 | +0.3% | -4.591 to +7.949 | EVEN, under the floor |
| temperature, peak (C) | 68.33 | 68 | -0.5% | -1.768 to +1.101 | EVEN, under the floor |
| temperature, mean (C) | 53.43 | 53.21 | -0.4% | -0.8908 to +0.4473 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.974e+04 | 4.968e+04 | -0.1% | -374.5 to +266.7 | EVEN, under the floor |
| power-capped share of samples | 0.6395 | 0.6407 | +0.2% | -0.01726 to +0.01974 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 37.64 | 38.38 | +2.0% | -0.1556 to +1.633 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.972e+04 | 4.876e+04 | -1.9% | -2103 to +189 | GAIN, not beyond the noise |
| energy per served request (J) | 26.57 | 26.06 | -1.9% | -1.124 to +0.101 | GAIN, not beyond the noise |
| power, GPU mean (W) | 233.9 | 229.4 | -1.9% | -10.27 to +1.409 | GAIN, not beyond the noise |
| requests served | 1871 | 1871 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 90.15 | 90.31 | +0.2% | -0.5929 to +0.8998 | EVEN, under the floor |
| response time, 95th percentile (ms) | 278.6 | 277.8 | -0.3% | -5.277 to +3.681 | EVEN, under the floor |
| response time, 99th percentile (ms) | 510.3 | 509.5 | -0.2% | -5.935 to +4.359 | EVEN, under the floor |
| temperature, peak (C) | 68 | 67.67 | -0.5% | -3.202 to +2.535 | EVEN, under the floor |
| temperature, mean (C) | 53.21 | 53.27 | +0.1% | -0.3015 to +0.423 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.968e+04 | 4.969e+04 | +0.0% | -143.5 to +151.9 | EVEN, under the floor |
| power-capped share of samples | 0.6407 | 0.6381 | -0.4% | -0.01709 to +0.01185 | EVEN, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 37.34 -> 38.38 served requests per kJ, difference +1.037 (95% interval -0.07349 to +2.147).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 2 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 2 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*