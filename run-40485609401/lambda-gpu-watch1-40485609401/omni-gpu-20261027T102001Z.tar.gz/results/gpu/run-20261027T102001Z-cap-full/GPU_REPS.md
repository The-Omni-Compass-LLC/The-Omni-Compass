# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
5 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 62.36 | 62.38 | 62.34 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.245e+04 | 9.242e+04 | 9.205e+04 |
| energy per served request (J) | 16.04 | 16.03 | 16.04 |
| power, GPU mean (W) | 278.1 | 277.9 | 276.7 |
| requests served | 5765 | 5765 | 5738 |
| requests not served | 1232 | 1232 | 1259 |
| response time, mean (ms) | 4.143e+04 | 4.154e+04 | 4.197e+04 |
| response time, 95th percentile (ms) | 7.794e+04 | 7.802e+04 | 7.911e+04 |
| response time, 99th percentile (ms) | 8.066e+04 | 8.07e+04 | 8.181e+04 |
| temperature, peak (C) | 60 | 60.6 | 60.6 |
| temperature, mean (C) | 57.84 | 58.14 | 58.09 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.245e+04 | 9.246e+04 | 9.204e+04 |
| power-capped share of samples | 0.9925 | 0.9924 | 0.4138 |

## Total: Omni governs against native, 5 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.36 | 62.34 | -0.0% | -0.1751 to +0.1362 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.245e+04 | 9.205e+04 | -0.4% | -905.6 to +103.2 | EVEN, under the floor |
| energy per served request (J) | 16.04 | 16.04 | +0.0% | -0.0351 to +0.04511 | EVEN, under the floor |
| power, GPU mean (W) | 278.1 | 276.7 | -0.5% | -2.85 to +0.2139 | EVEN, under the floor |
| requests served | 5765 | 5738 | -0.5% | -66.31 to +12.71 | EVEN, under the floor |
| requests not served | 1232 | 1259 | +2.2% | -12.71 to +66.31 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.143e+04 | 4.197e+04 | +1.3% | -507.5 to +1599 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.794e+04 | 7.911e+04 | +1.5% | -484.4 to +2827 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.066e+04 | 8.181e+04 | +1.4% | -588.1 to +2888 | LOSS, not beyond the noise |
| temperature, peak (C) | 60 | 60.6 | +1.0% | -0.5104 to +1.71 | power given, not beyond the noise |
| temperature, mean (C) | 57.84 | 58.09 | +0.4% | -0.5046 to +1.018 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.245e+04 | 9.204e+04 | -0.4% | -871.3 to +48.01 | EVEN, under the floor |
| power-capped share of samples | 0.9925 | 0.4138 | -58.3% | -1.077 to -0.08031 | LOSS, clear of the noise |

## Observation: omni watching (writes nothing) against native, 5 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.36 | 62.38 | +0.0% | -0.1556 to +0.2019 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.245e+04 | 9.242e+04 | -0.0% | -97.01 to +28.42 | EVEN, under the floor |
| energy per served request (J) | 16.04 | 16.03 | -0.0% | -0.05197 to +0.0401 | EVEN, under the floor |
| power, GPU mean (W) | 278.1 | 277.9 | -0.1% | -0.4421 to +0.06927 | EVEN, under the floor |
| requests served | 5765 | 5765 | +0.0% | -14.29 to +14.29 | EVEN, under the floor |
| requests not served | 1232 | 1232 | +0.0% | -14.29 to +14.29 | EVEN, under the floor |
| response time, mean (ms) | 4.143e+04 | 4.154e+04 | +0.3% | -472.5 to +703 | EVEN, under the floor |
| response time, 95th percentile (ms) | 7.794e+04 | 7.802e+04 | +0.1% | -530.5 to +704.3 | EVEN, under the floor |
| response time, 99th percentile (ms) | 8.066e+04 | 8.07e+04 | +0.0% | -687 to +756.1 | EVEN, under the floor |
| temperature, peak (C) | 60 | 60.6 | +1.0% | -0.5104 to +1.71 | power given, not beyond the noise |
| temperature, mean (C) | 57.84 | 58.14 | +0.5% | -0.2746 to +0.8717 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.245e+04 | 9.246e+04 | +0.0% | -2.787 to +24.33 | EVEN, under the floor |
| power-capped share of samples | 0.9925 | 0.9924 | -0.0% | -0.001091 to +0.0008539 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 5 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.38 | 62.34 | -0.1% | -0.1855 to +0.1003 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.242e+04 | 9.205e+04 | -0.4% | -854.4 to +120.6 | EVEN, under the floor |
| energy per served request (J) | 16.03 | 16.04 | +0.1% | -0.02578 to +0.04766 | EVEN, under the floor |
| power, GPU mean (W) | 277.9 | 276.7 | -0.4% | -2.678 to +0.4152 | EVEN, under the floor |
| requests served | 5765 | 5738 | -0.5% | -58.2 to +4.599 | EVEN, under the floor |
| requests not served | 1232 | 1259 | +2.2% | -4.599 to +58.2 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.154e+04 | 4.197e+04 | +1.0% | -293.7 to +1155 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.802e+04 | 7.911e+04 | +1.4% | -290.4 to +2459 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.07e+04 | 8.181e+04 | +1.4% | -220 to +2451 | LOSS, not beyond the noise |
| temperature, peak (C) | 60.6 | 60.6 | +0.0% | -1.756 to +1.756 | EVEN, under the floor |
| temperature, mean (C) | 58.14 | 58.09 | -0.1% | -1.099 to +1.015 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.246e+04 | 9.204e+04 | -0.5% | -883.9 to +39.06 | EVEN, under the floor |
| power-capped share of samples | 0.9924 | 0.4138 | -58.3% | -1.078 to -0.07932 | LOSS, clear of the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 62.36 -> 62.34 served requests per kJ, difference -0.01943 (95% interval -0.1751 to +0.1362).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time held (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): EVEN, under the floor.
**Result, by rule: EVEN (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 2 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 3 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| omni | 4 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| omni | 5 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| watch | 1 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 2 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 3 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| watch | 4 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |
| watch | 5 | 160 | 0 | n/a | n/a | 0 | 160 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 7.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*