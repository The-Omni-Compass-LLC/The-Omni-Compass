# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
5 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 44.34 | 44.24 | 44.17 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.199e+04 | 6.213e+04 | 6.226e+04 |
| energy per served request (J) | 22.55 | 22.6 | 22.65 |
| power, GPU mean (W) | 186.5 | 186.9 | 187.3 |
| requests served | 2749 | 2749 | 2749 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 101.1 | 101.1 | 101.9 |
| response time, 95th percentile (ms) | 315.9 | 314.8 | 317.1 |
| response time, 99th percentile (ms) | 560.7 | 559.9 | 563.6 |
| temperature, peak (C) | 57.6 | 57.8 | 58.2 |
| temperature, mean (C) | 48 | 48.15 | 48.59 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.229e+04 | 6.231e+04 | 6.208e+04 |
| power-capped share of samples | 0.6717 | 0.6782 | 0.6431 |

## Total: Omni governs against native, 5 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.34 | 44.17 | -0.4% | -1.103 to +0.7488 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.199e+04 | 6.226e+04 | +0.4% | -1050 to +1589 | EVEN, under the floor |
| energy per served request (J) | 22.55 | 22.65 | +0.4% | -0.3818 to +0.578 | EVEN, under the floor |
| power, GPU mean (W) | 186.5 | 187.3 | +0.4% | -3.169 to +4.785 | EVEN, under the floor |
| requests served | 2749 | 2749 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 101.1 | 101.9 | +0.8% | -0.8756 to +2.467 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 315.9 | 317.1 | +0.4% | -4.772 to +7.192 | EVEN, under the floor |
| response time, 99th percentile (ms) | 560.7 | 563.6 | +0.5% | -11.21 to +16.99 | LOSS, not beyond the noise |
| temperature, peak (C) | 57.6 | 58.2 | +1.0% | -0.8155 to +2.015 | power given, not beyond the noise |
| temperature, mean (C) | 48 | 48.59 | +1.2% | -0.7191 to +1.885 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.229e+04 | 6.208e+04 | -0.3% | -503.5 to +89.25 | EVEN, under the floor |
| power-capped share of samples | 0.6717 | 0.6431 | -4.3% | -0.04581 to -0.01133 | LOSS, clear of the noise |

## Observation: omni watching (writes nothing) against native, 5 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.34 | 44.24 | -0.2% | -0.8649 to +0.665 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.199e+04 | 6.213e+04 | +0.2% | -932.1 to +1211 | EVEN, under the floor |
| energy per served request (J) | 22.55 | 22.6 | +0.2% | -0.3391 to +0.4405 | EVEN, under the floor |
| power, GPU mean (W) | 186.5 | 186.9 | +0.2% | -2.826 to +3.648 | EVEN, under the floor |
| requests served | 2749 | 2749 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 101.1 | 101.1 | +0.0% | -0.915 to +0.9514 | EVEN, under the floor |
| response time, 95th percentile (ms) | 315.9 | 314.8 | -0.4% | -5.875 to +3.626 | EVEN, under the floor |
| response time, 99th percentile (ms) | 560.7 | 559.9 | -0.1% | -8.508 to +6.912 | EVEN, under the floor |
| temperature, peak (C) | 57.6 | 57.8 | +0.3% | -1.16 to +1.56 | EVEN, under the floor |
| temperature, mean (C) | 48 | 48.15 | +0.3% | -0.756 to +1.049 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.229e+04 | 6.231e+04 | +0.0% | -192.6 to +246.9 | EVEN, under the floor |
| power-capped share of samples | 0.6717 | 0.6782 | +1.0% | -0.005094 to +0.01806 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 5 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.24 | 44.17 | -0.2% | -1.511 to +1.357 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.213e+04 | 6.226e+04 | +0.2% | -1899 to +2159 | EVEN, under the floor |
| energy per served request (J) | 22.6 | 22.65 | +0.2% | -0.6907 to +0.7855 | EVEN, under the floor |
| power, GPU mean (W) | 186.9 | 187.3 | +0.2% | -5.724 to +6.518 | EVEN, under the floor |
| requests served | 2749 | 2749 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 101.1 | 101.9 | +0.8% | -0.6471 to +2.202 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 314.8 | 317.1 | +0.7% | -5.326 to +9.995 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 559.9 | 563.6 | +0.7% | -12.02 to +19.4 | LOSS, not beyond the noise |
| temperature, peak (C) | 57.8 | 58.2 | +0.7% | -0.28 to +1.08 | power given, not beyond the noise |
| temperature, mean (C) | 48.15 | 48.59 | +0.9% | -0.7837 to +1.657 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.231e+04 | 6.208e+04 | -0.4% | -607.3 to +138.8 | EVEN, under the floor |
| power-capped share of samples | 0.6782 | 0.6431 | -5.2% | -0.04584 to -0.02427 | LOSS, clear of the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 44.34 -> 44.17 served requests per kJ, difference -0.1771 (95% interval -1.103 to +0.7488).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): EVEN, under the floor.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 2 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 3 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 4 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 5 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 1 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| watch | 2 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| watch | 3 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 4 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 5 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 52.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*