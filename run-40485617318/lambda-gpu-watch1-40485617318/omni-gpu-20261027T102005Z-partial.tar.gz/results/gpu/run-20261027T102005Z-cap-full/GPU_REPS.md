# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
5 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 65.86 | 65.86 | 65.87 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.264e+04 | 9.264e+04 | 9.26e+04 |
| energy per served request (J) | 15.18 | 15.18 | 15.18 |
| power, GPU mean (W) | 278.7 | 278.7 | 278.6 |
| requests served | 6101 | 6101 | 6100 |
| requests not served | 1220 | 1220 | 1221 |
| response time, mean (ms) | 3.965e+04 | 3.964e+04 | 3.964e+04 |
| response time, 95th percentile (ms) | 7.385e+04 | 7.389e+04 | 7.393e+04 |
| response time, 99th percentile (ms) | 7.76e+04 | 7.766e+04 | 7.767e+04 |
| temperature, peak (C) | 59.8 | 59.6 | 59.8 |
| temperature, mean (C) | 57.19 | 57.15 | 57.26 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.263e+04 | 9.263e+04 | 9.262e+04 |
| power-capped share of samples | 0.993 | 0.993 | 0.9923 |

## Total: Omni governs against native, 5 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 65.86 | 65.87 | +0.0% | -0.4795 to +0.5025 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.264e+04 | 9.26e+04 | -0.0% | -104.6 to +29.55 | EVEN, under the floor |
| energy per served request (J) | 15.18 | 15.18 | -0.0% | -0.1161 to +0.1107 | EVEN, under the floor |
| power, GPU mean (W) | 278.7 | 278.6 | -0.0% | -0.2938 to +0.0529 | EVEN, under the floor |
| requests served | 6101 | 6100 | -0.0% | -45.08 to +42.28 | EVEN, under the floor |
| requests not served | 1220 | 1221 | +0.1% | -42.28 to +45.08 | EVEN, under the floor |
| response time, mean (ms) | 3.965e+04 | 3.964e+04 | -0.0% | -598.8 to +574 | EVEN, under the floor |
| response time, 95th percentile (ms) | 7.385e+04 | 7.393e+04 | +0.1% | -1604 to +1766 | EVEN, under the floor |
| response time, 99th percentile (ms) | 7.76e+04 | 7.767e+04 | +0.1% | -1562 to +1709 | EVEN, under the floor |
| temperature, peak (C) | 59.8 | 59.8 | +0.0% | -0.8778 to +0.8778 | EVEN, under the floor |
| temperature, mean (C) | 57.19 | 57.26 | +0.1% | -0.4482 to +0.5944 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.263e+04 | 9.262e+04 | -0.0% | -32.74 to +8.996 | EVEN, under the floor |
| power-capped share of samples | 0.993 | 0.9923 | -0.1% | -0.001347 to -0.0001005 | EVEN, under the floor |

## Observation: omni watching (writes nothing) against native, 5 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 65.86 | 65.86 | -0.0% | -0.4906 to +0.4895 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.264e+04 | 9.264e+04 | -0.0% | -89.65 to +85.2 | EVEN, under the floor |
| energy per served request (J) | 15.18 | 15.18 | +0.0% | -0.1128 to +0.1132 | EVEN, under the floor |
| power, GPU mean (W) | 278.7 | 278.7 | -0.0% | -0.3336 to +0.3237 | EVEN, under the floor |
| requests served | 6101 | 6101 | -0.0% | -41.69 to +41.29 | EVEN, under the floor |
| requests not served | 1220 | 1220 | +0.0% | -41.29 to +41.69 | EVEN, under the floor |
| response time, mean (ms) | 3.965e+04 | 3.964e+04 | -0.0% | -476 to +448.3 | EVEN, under the floor |
| response time, 95th percentile (ms) | 7.385e+04 | 7.389e+04 | +0.1% | -1521 to +1606 | EVEN, under the floor |
| response time, 99th percentile (ms) | 7.76e+04 | 7.766e+04 | +0.1% | -1437 to +1566 | EVEN, under the floor |
| temperature, peak (C) | 59.8 | 59.6 | -0.3% | -0.7552 to +0.3552 | EVEN, under the floor |
| temperature, mean (C) | 57.19 | 57.15 | -0.1% | -0.4049 to +0.335 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.263e+04 | 9.263e+04 | -0.0% | -27.95 to +19.75 | EVEN, under the floor |
| power-capped share of samples | 0.993 | 0.993 | -0.0% | -0.0007458 to +0.0007442 | EVEN, under the floor |

## Authority: Omni governs against Omni watching, 5 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 65.86 | 65.87 | +0.0% | -0.6627 to +0.6868 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.264e+04 | 9.26e+04 | -0.0% | -125 to +54.45 | EVEN, under the floor |
| energy per served request (J) | 15.18 | 15.18 | -0.0% | -0.1585 to +0.1527 | EVEN, under the floor |
| power, GPU mean (W) | 278.7 | 278.6 | -0.0% | -0.43 to +0.1991 | EVEN, under the floor |
| requests served | 6101 | 6100 | -0.0% | -60.86 to +58.46 | EVEN, under the floor |
| requests not served | 1220 | 1221 | +0.1% | -58.46 to +60.86 | EVEN, under the floor |
| response time, mean (ms) | 3.964e+04 | 3.964e+04 | +0.0% | -846.9 to +849.8 | EVEN, under the floor |
| response time, 95th percentile (ms) | 7.389e+04 | 7.393e+04 | +0.1% | -2338 to +2415 | EVEN, under the floor |
| response time, 99th percentile (ms) | 7.766e+04 | 7.767e+04 | +0.0% | -2176 to +2195 | EVEN, under the floor |
| temperature, peak (C) | 59.6 | 59.8 | +0.3% | -0.3552 to +0.7552 | EVEN, under the floor |
| temperature, mean (C) | 57.15 | 57.26 | +0.2% | -0.3576 to +0.5738 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.263e+04 | 9.262e+04 | -0.0% | -27.19 to +11.64 | EVEN, under the floor |
| power-capped share of samples | 0.993 | 0.9923 | -0.1% | -0.001056 to -0.0003904 | EVEN, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 65.86 -> 65.87 served requests per kJ, difference +0.01154 (95% interval -0.4795 to +0.5025).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): EVEN, under the floor.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 2 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 3 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 4 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 5 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 1 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 2 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 3 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 4 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 5 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 10.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*