# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-40GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 73630cd05351; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 38.91 | 38.75 | 39.32 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 4.955e+04 | 4.977e+04 | 4.904e+04 |
| energy per served request (J) | 25.7 | 25.81 | 25.43 |
| power, GPU mean (W) | 233.3 | 234.3 | 230.9 |
| requests served | 1928 | 1928 | 1928 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 94.65 | 94.63 | 94.75 |
| response time, 95th percentile (ms) | 301.4 | 301.4 | 302.9 |
| response time, 99th percentile (ms) | 508.8 | 509 | 509.4 |
| temperature, peak (C) | 70.33 | 70.67 | 70.67 |
| temperature, mean (C) | 55.25 | 55.38 | 55.48 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 4.912e+04 | 4.923e+04 | 4.914e+04 |
| power-capped share of samples | 0.6479 | 0.6392 | 0.6438 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.91 | 39.32 | +1.0% | -0.2101 to +1.024 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.955e+04 | 4.904e+04 | -1.0% | -1291 to +265.1 | GAIN, not beyond the noise |
| energy per served request (J) | 25.7 | 25.43 | -1.0% | -0.6694 to +0.1375 | GAIN, not beyond the noise |
| power, GPU mean (W) | 233.3 | 230.9 | -1.0% | -6.071 to +1.24 | GAIN, not beyond the noise |
| requests served | 1928 | 1928 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 94.65 | 94.75 | +0.1% | -0.3107 to +0.5121 | EVEN, under the floor |
| response time, 95th percentile (ms) | 301.4 | 302.9 | +0.5% | -3.465 to +6.488 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 508.8 | 509.4 | +0.1% | -0.03977 to +1.39 | EVEN, under the floor |
| temperature, peak (C) | 70.33 | 70.67 | +0.5% | -1.101 to +1.768 | EVEN, under the floor |
| temperature, mean (C) | 55.25 | 55.48 | +0.4% | -0.537 to +0.9935 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.912e+04 | 4.914e+04 | +0.0% | -151.3 to +190.6 | EVEN, under the floor |
| power-capped share of samples | 0.6479 | 0.6438 | -0.6% | -0.05378 to +0.04573 | LOSS, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.91 | 38.75 | -0.4% | -1.624 to +1.293 | EVEN, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.955e+04 | 4.977e+04 | +0.4% | -1647 to +2079 | EVEN, under the floor |
| energy per served request (J) | 25.7 | 25.81 | +0.4% | -0.8543 to +1.078 | EVEN, under the floor |
| power, GPU mean (W) | 233.3 | 234.3 | +0.4% | -7.733 to +9.745 | EVEN, under the floor |
| requests served | 1928 | 1928 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 94.65 | 94.63 | -0.0% | -0.7394 to +0.7 | EVEN, under the floor |
| response time, 95th percentile (ms) | 301.4 | 301.4 | +0.0% | -5.406 to +5.46 | EVEN, under the floor |
| response time, 99th percentile (ms) | 508.8 | 509 | +0.0% | -1.389 to +1.863 | EVEN, under the floor |
| temperature, peak (C) | 70.33 | 70.67 | +0.5% | -2.535 to +3.202 | EVEN, under the floor |
| temperature, mean (C) | 55.25 | 55.38 | +0.2% | -0.6324 to +0.88 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.912e+04 | 4.923e+04 | +0.2% | -72.56 to +306.1 | EVEN, under the floor |
| power-capped share of samples | 0.6479 | 0.6392 | -1.3% | -0.03688 to +0.01955 | LOSS, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.75 | 39.32 | +1.5% | -1.086 to +2.232 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.977e+04 | 4.904e+04 | -1.5% | -2835 to +1378 | GAIN, not beyond the noise |
| energy per served request (J) | 25.81 | 25.43 | -1.5% | -1.47 to +0.7145 | GAIN, not beyond the noise |
| power, GPU mean (W) | 234.3 | 230.9 | -1.5% | -13.34 to +6.494 | GAIN, not beyond the noise |
| requests served | 1928 | 1928 | +0.0% | +0 to +0 | EVEN, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | EVEN, the same |
| response time, mean (ms) | 94.63 | 94.75 | +0.1% | -0.293 to +0.5339 | EVEN, under the floor |
| response time, 95th percentile (ms) | 301.4 | 302.9 | +0.5% | -3.483 to +6.452 | EVEN, under the floor |
| response time, 99th percentile (ms) | 509 | 509.4 | +0.1% | -1.9 to +2.777 | EVEN, under the floor |
| temperature, peak (C) | 70.67 | 70.67 | +0.0% | -2.484 to +2.484 | EVEN, under the floor |
| temperature, mean (C) | 55.38 | 55.48 | +0.2% | -0.2961 to +0.505 | EVEN, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.923e+04 | 4.914e+04 | -0.2% | -204.5 to +10.37 | EVEN, under the floor |
| power-capped share of samples | 0.6392 | 0.6438 | +0.7% | -0.04151 to +0.05079 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 38.91 -> 39.32 served requests per kJ, difference +0.407 (95% interval -0.2101 to +1.024).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: EVEN, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: EVEN (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 2 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| omni | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 1 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 2 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |
| watch | 3 | 103 | 0 | n/a | n/a | 0 | 103 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*